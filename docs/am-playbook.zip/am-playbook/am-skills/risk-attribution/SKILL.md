---
name: risk-attribution
description: >
  Use this skill when analysing portfolio risk, running a risk review, preparing
  for an IC risk discussion, or responding to a risk query. Triggers on 'risk
  attribution', 'risk breakdown', 'factor decomposition', 'where is our risk
  coming from', 'what is our tracking error', 'VaR report', 'factor exposures',
  'check our risk budget', 'risk review for IC', 'what are our biggest risk
  positions', 'concentration analysis', or 'are we within mandate risk limits'.
  Covers equity, fixed income, and multi-asset portfolios. Do NOT use for
  writing client letters — use /skills/client-reporting instead. Do NOT use for
  full portfolio performance review — use /skills/portfolio-review instead.
  Do NOT use for a formal pass/fail rule-by-rule compliance scan against the
  IPS or restricted lists — use /skills/compliance-check instead.
version: "1.0"
updated: "2026-06-13"
---

# Risk Attribution Skill

## Safety — Read First

- NEVER fabricate risk metrics — only use what the user provides
- Flag mandate breaches or limit approaches immediately, before the rest of the output
- If the user provides a risk system export (Barra, Aladdin, Bloomberg PORT), note the as-of date prominently
- VaR and other statistical measures are model-dependent — note the model and confidence level used

## The Risk Review Process

```
1. GATHER     — Holdings, weights, factor exposures, risk model source, as-of date
2. SUMMARISE  — Top-level risk stats: vol, TE, VaR, drawdown
3. DECOMPOSE  — Factor attribution of risk (systematic vs idiosyncratic)
4. CONCENTRATE — Concentration by name, sector, geography, asset class
5. BUDGET     — Check all metrics against mandate limits
6. FLAG       — Breach or watch items, recommended actions
```

## Output Template

```
## Risk Attribution: {Fund} — {As-of Date}

{BREACH FLAG — if any limit is breached, state it here before everything else}

### Portfolio Risk Summary
| Measure | Portfolio | Limit | Headroom | Status |
|---------|-----------|-------|----------|--------|
| Volatility (ann.) | {X}% | {limit or N/A} | | OK / WATCH / BREACH |
| Tracking Error (ann.) | {X}% | | | |
| VaR (95%, 1-day) | {X}% | | | |
| VaR (99%, 1-day) | {X}% | | | |
| Max Drawdown (YTD) | {X}% | | | |
| Beta to benchmark | {X} | | | |

### Factor Risk Decomposition
| Factor | Exposure | % of Total Portfolio Risk | Direction vs BM |
|--------|----------|--------------------------|----------------|
| Market (Beta) | | | Over / Under / Neutral |
| Size (small vs large) | | | |
| Value | | | |
| Momentum | | | |
| Quality | | | |
| Duration (fixed income) | | | |
| Credit Spread | | | |
| Idiosyncratic / Residual | | | |

### Concentration Analysis
| Metric | Value | Limit | Status |
|--------|-------|-------|--------|
| Top 1 position | {X}% | | |
| Top 5 positions | {X}% | | |
| Top 10 positions | {X}% | | |
| Largest sector | {name} at {X}% | | |
| Largest geography | {name} at {X}% | | |
| Active share vs benchmark | {X}% | | |

### Risk Budget Status
{One paragraph. Overall assessment: within budget / approaching limits / breach. 
Note any trends — is risk rising or falling vs prior period?}

### Limit Watch Items
| Item | Current | Limit | Action Required | Owner |
|------|---------|-------|----------------|-------|
| {metric} | | | {specific action} | |

### Recommended Risk Actions
1. {Action — with rationale}
2. {Action}

### Notes
- Risk model: {Barra / Bloomberg PORT / Aladdin / internal / not specified}
- Data as of: {date}
- Currency: {base currency}
```

## Worked Examples

### Example 1 — Equity fund risk review

INPUT:
"Risk review for the European Equity fund. TE is 5.2% vs our 4% guideline. We're running 8% in financials overweight. Top holding is 6.2% in Novo Nordisk vs 3% mandate limit for single names. Barra model, as of 10 Jun 2026."

OUTPUT:
```
## Risk Attribution: European Equity Fund — 10 Jun 2026

⚠️ MANDATE BREACH: Single name limit exceeded — Novo Nordisk at 6.2% vs 3.0% limit.
⚠️ WATCH: Tracking error at 5.2% vs 4.0% guideline — 120bps above target.

### Portfolio Risk Summary
| Measure | Portfolio | Limit | Headroom | Status |
|---------|-----------|-------|----------|--------|
| Tracking Error (ann.) | 5.2% | 4.0% | -120bps | BREACH |
| Beta to STOXX 600 | ~1.05 | N/A | — | OK |

### Concentration Analysis
| Metric | Value | Limit | Status |
|--------|-------|-------|--------|
| Top 1 position (Novo Nordisk) | 6.2% | 3.0% | **BREACH** |
| Financials overweight vs BM | +8.0% | N/A | WATCH |

### Risk Budget Status
Tracking error is 130% of the 4% guideline, driven primarily by the concentration in Novo Nordisk and the elevated financials overweight. Both factors are additive — the single name breach is also contributing to sector concentration risk. Tracking error should be expected to remain elevated unless the Novo Nordisk position is reduced.

### Limit Watch Items
| Item | Current | Limit | Action Required | Owner |
|------|---------|-------|----------------|-------|
| Novo Nordisk single name | 6.2% | 3.0% | Reduce to ≤3.0% — requires trade | PM |
| Tracking error | 5.2% | 4.0% | Reduce concentration or add offsetting positions | PM |

### Recommended Risk Actions
1. **Immediate (today):** Trim Novo Nordisk from 6.2% to ≤3.0% — this is a mandate breach and requires a trade
2. **This week:** Review financials overweight — assess whether 8% active position is intentional and document rationale if so

### Notes
- Risk model: Barra (Axioma)
- Data as of: 10 Jun 2026
- Currency: EUR
```

### Example 2 — Multi-asset risk snapshot

INPUT:
"Quick risk snapshot for our balanced fund. 65% equities, 30% bonds, 5% cash. Equity beta is 0.62 to MSCI World, duration is 3.2 years. We target an overall fund vol of 8% or less. Estimated vol is 7.1%. No breaches."

OUTPUT:
```
## Risk Attribution: Balanced Fund — Jun 2026

No limit breaches identified.

### Portfolio Risk Summary
| Measure | Portfolio | Limit | Headroom | Status |
|---------|-----------|-------|----------|--------|
| Volatility (ann., est.) | 7.1% | 8.0% | 90bps | OK |
| Equity beta (to MSCI World) | 0.62 | N/A | — | OK |
| Modified Duration | 3.2 yrs | N/A | — | OK |

### Asset Allocation
| Asset Class | Weight | Target | +/- |
|-------------|--------|--------|-----|
| Equities | 65% | 60% | +5% |
| Bonds | 30% | 35% | -5% |
| Cash | 5% | 5% | 0% |

### Risk Budget Status
Portfolio volatility at 7.1% is within the 8.0% limit with 90bps of headroom. The equity overweight (+5% vs target) is the primary driver of vol — if equities sell off and equity vol rises, the fund could approach or test the limit. No immediate action required.

### Limit Watch Items
None — all measures within limits.

### Recommended Risk Actions
1. Monitor equity drift — if equities appreciate further, the +5% overweight may push vol toward the 8% ceiling. Reassess if equity allocation reaches 67-68%.

### Notes
- Risk model: Internal / estimated
- Data as of: Jun 2026
- Currency: GBP
```

## Factor Reference Guide (Equity)

| Factor | High exposure means | Low exposure means |
|--------|--------------------|--------------------|
| Market (Beta > 1) | Amplifies market moves | Defensive — less drawdown in selloffs |
| Size (positive) | Tilted to small caps | Large cap bias |
| Value (positive) | Cheap stocks (low P/B, P/E) | Growth / momentum stocks |
| Momentum | Recent winners | Recent laggards or contrarian |
| Quality | High ROE, low leverage | Lower quality / cyclical bias |
| Low Volatility | Defensive tilt | Cyclical / high-beta bias |

## Fixed Income Risk Reference

| Measure | What it tells you |
|---------|------------------|
| Modified Duration | Price sensitivity to a 1% parallel shift in rates |
| DV01 | Dollar value change per 1bp move in rates |
| Credit Spread Duration | Sensitivity to credit spread moves |
| VaR (95%, 1-day) | Maximum expected loss on 95% of trading days |
| CVaR / Expected Shortfall | Average loss in the worst 5% of scenarios |
