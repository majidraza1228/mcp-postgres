---
name: client-reporting
description: >
  Use this skill when generating client-facing commentary, quarterly letters,
  monthly factsheet text, or bespoke client updates. Triggers on 'write client
  commentary', 'write a quarterly letter', 'client report for', 'factsheet
  commentary', 'write the manager commentary', 'draft a client update', 'write
  the quarterly review for the client', 'investor letter', or 'write what goes
  in the factsheet'. Adjusts tone and depth for retail vs institutional clients.
  Do NOT use for internal IC notes or investment memos — use
  /skills/investment-memo instead. Do NOT use for internal risk reviews — use
  /skills/risk-attribution instead.
version: "1.0"
updated: "2026-06-13"
---

# Client Reporting Skill

## Safety — Read First

- NEVER fabricate performance numbers — use only what the user provides
- NEVER make unqualified forward-looking statements — always use: "we believe", "in our view", "we expect"
- NEVER include internal risk metrics (VaR, TE, position limits) unless client-approved for disclosure
- NEVER include specific position names if the client mandate prohibits portfolio transparency
- All commentary must end with a regulatory disclaimer placeholder — remind the user to insert the appropriate one for their jurisdiction

## The Commentary Process

```
1. IDENTIFY   — Client type, fund, period, distribution channel
2. CONTEXT    — Market backdrop: 2-3 key events that shaped the period
3. PERFORMANCE — What the fund returned, vs benchmark, why
4. POSITIONING — How the portfolio is currently positioned and why
5. OUTLOOK     — Forward view with appropriate uncertainty language
6. TONE CHECK  — Match tone to client type (retail = plain English, institutional = more technical)
```

## Output Template

```
## {Fund Name} — {Quarter / Month} {Year} Commentary

### Market Review
{2-3 sentences. Key macro events, market moves, central bank actions that defined the period.
Factual and neutral — no fund opinion in this section.}

### Portfolio Performance
{Fund Name} returned {X}% during {period}, {outperforming / underperforming / in line with}
the {Benchmark Name} which returned {Y}%.

{Attribution paragraph: 2-3 sentences explaining what drove performance — name top contributors
and detractors, explain in plain language. Avoid jargon: "our overweight in X" not "our
long duration tilt via curve steepeners".}

### Portfolio Positioning
{1-2 paragraphs explaining where the fund is currently positioned and the investment rationale.
Frame around themes and views, not just weights. Examples: "We remain constructive on European
financials given...", "We have reduced our exposure to... because..."}

### Outlook
{2-3 sentences. Forward view with uncertainty language. End with how the portfolio is
positioned for the environment ahead.}

---
*Past performance is not a reliable indicator of future results.*
*[Insert required regulatory disclosure for your jurisdiction.]*
```

## Worked Examples

### Example 1 — Quarterly equity letter (institutional)

INPUT:
"Write Q1 2026 commentary for our Global Equity fund. We returned +6.2% vs MSCI World +5.1%. Key drivers were our overweight US tech (AI theme, added +1.8%) and underweight China (China equities fell -4%). We reduced Europe given earnings uncertainty. Going forward we're cautious on valuations but think AI capex cycle keeps tech supported."

OUTPUT:
```
## Global Equity Fund — Q1 2026 Commentary

### Market Review
Global equities advanced during Q1 2026, with the MSCI World Index returning +5.1% in USD terms. US equities led the rally, driven by continued enthusiasm around artificial intelligence infrastructure spending and resilient corporate earnings. Chinese equities were a notable detractor as stimulus expectations were disappointed and domestic consumer confidence remained subdued. European markets were mixed, with earnings uncertainty weighing on cyclical sectors.

### Portfolio Performance
The Global Equity Fund returned +6.2% during Q1 2026, outperforming the MSCI World Index by 110 basis points.

The primary driver of outperformance was our overweight position in US technology companies benefiting from the AI capital expenditure cycle, which contributed approximately +180 basis points relative to benchmark. Our underweight exposure to Chinese equities — where the benchmark suffered a meaningful decline — added a further +70 basis points. Partially offsetting this, our reduced European allocation detracted modestly as pockets of the region's equity market outperformed our expectations.

### Portfolio Positioning
We enter Q2 2026 with a continued overweight in US technology, where we believe the structural AI investment cycle has further to run. Data centre infrastructure, semiconductor equipment, and enterprise software with credible AI integration remain our preferred themes within the sector.

We have maintained our cautious stance on Chinese equities, reflecting ongoing uncertainty around stimulus delivery and the pace of consumer recovery. In Europe, we have selectively added to financial sector positions where earnings visibility has improved, while remaining underweight discretionary and industrials exposed to slowing export demand.

### Outlook
We are mindful that global equity valuations, particularly in the US, leave limited margin for earnings disappointment. However, in our view, the AI-driven capex cycle represents a durable growth driver that can sustain technology sector earnings through the near term. We expect volatility to remain elevated around central bank policy decisions and geopolitical developments, and the portfolio is positioned with this in mind — maintaining quality bias and adequate liquidity.

---
*Past performance is not a reliable indicator of future results.*
*[Insert required regulatory disclosure for your jurisdiction.]*
```

### Example 2 — Monthly factsheet commentary (retail)

INPUT:
"Monthly commentary for May 2026 for a UK balanced fund. We returned -0.8% vs -0.6% for the 60/40 benchmark. Bonds dragged — gilt yields rose on sticky inflation data. Our equity book was flat. Keep it short and plain English — this goes on the factsheet."

OUTPUT:
```
## UK Balanced Fund — May 2026 Commentary

### Market Review
May was a difficult month for UK fixed income markets. Gilt yields rose sharply following higher-than-expected inflation data, which dampened hopes of near-term Bank of England rate cuts. UK equities were broadly flat as investors digested the inflation news alongside mixed corporate results.

### Portfolio Performance
The Fund returned -0.8% in May 2026, compared to -0.6% for the benchmark.

The shortfall relative to benchmark was driven primarily by our bond holdings, where rising gilt yields created headwinds. Our equity portfolio held its ground and broadly matched the market. We entered May with a slightly longer duration position than the benchmark, which amplified the impact of the yield move.

### Portfolio Positioning
We have modestly reduced our interest rate sensitivity following May's market moves, reflecting our view that inflation remains stickier than the market had priced. Our equity allocation remains diversified across UK and global shares, with a preference for companies with resilient earnings and strong cash generation.

### Outlook
We believe the UK inflation picture will gradually improve over the remainder of 2026, which should allow the Bank of England to begin easing policy — but we expect this process to be slower than markets had anticipated earlier in the year. We are positioned for continued volatility in bond markets while maintaining our long-term investment approach.

---
*Past performance is not a reliable indicator of future results. The value of investments can fall as well as rise.*
*[Insert required FCA/UK regulatory disclosure.]*
```

## Tone Guide by Client Type

| Client Type | Tone | Jargon | Length |
|-------------|------|--------|--------|
| Retail / Fund factsheet | Plain English, accessible | Minimal — explain any technical terms | 200-400 words |
| Institutional / Pension | Professional, precise | Moderate — peers will know the terminology | 400-800 words |
| Family office / UHNW | Conversational, direct | Match to client sophistication | 300-600 words |
| Consultant / Gatekeeper | Analytical, benchmarked | Full — consultants expect technical detail | 600-1000 words |

## Compliance Checklist (Before Finalising)

- [ ] No unqualified forward-looking statements (checked: "we expect/believe/in our view")
- [ ] No fabricated or unverified performance numbers
- [ ] No internal-only information (mandate limits, VaR, position names if not approved)
- [ ] Regulatory disclaimer placeholder included
- [ ] Appropriate caveat on past performance
- [ ] Tone matches the client type and distribution channel
