---
name: compliance-check
description: >
  Use this skill when scanning a portfolio, trade, or proposed trade against the
  Investment Policy Statement (IPS), mandate rules, or restricted/exclusion
  lists, and producing a formal pass/fail compliance result. Triggers on
  'compliance check', 'run a compliance scan', 'check against the IPS',
  'restricted list check', 'pre-trade compliance', 'post-trade compliance
  check', 'is this trade compliant', 'check for mandate breaches',
  'exclusion list screen', 'issuer limit check', 'ESG exclusion check', or
  'ahead of trading, is this within mandate'. Produces a pass/fail rule-by-rule
  report, not just a narrative risk summary. Do NOT use for a full portfolio
  performance/positioning review — use /skills/portfolio-review instead. Do NOT
  use for factor/risk-budget analysis — use /skills/risk-attribution instead.
version: "1.0"
updated: "2026-07-02"
---

# Compliance Check Skill

## Safety — Read First

- NEVER fabricate limits, holdings, or rule text — only evaluate what the user provides
- If a rule's threshold or wording is not given, mark it "NOT EVALUATED — rule not provided" rather than guessing
- Any BREACH must be stated at the very top of the output, before anything else
- This is a compliance-support tool, not a substitute for the firm's official compliance system or officer sign-off — always end with a compliance sign-off reminder
- If client names, account numbers, or other PII are pasted, note it and exclude it from the output
- Restricted-list / exclusion-list membership is binary (in breach or not) — do not soften a breach into a "watch" item

## The Compliance Check Process

```
1. SCOPE      — Portfolio/mandate, IPS or rule source, as-of date, pre-trade vs post-trade
2. ENUMERATE  — List every rule to be checked (concentration, issuer, sector, country,
                liquidity, restricted list, ESG/exclusions, leverage, derivatives usage)
3. EVALUATE   — For each rule: current value vs. limit → PASS / WATCH / BREACH
4. FLAG       — Surface every BREACH immediately, then WATCH items
5. REMEDIATE  — Required action, owner, and deadline for each non-PASS item
6. SIGN-OFF   — Reviewer reminder — this output requires compliance officer review before action
```

## Output Template

```
## Compliance Check: {Fund / Mandate} — {As-of Date} {Pre-Trade / Post-Trade}

{BREACH FLAG — if any rule fails, state it here before everything else, e.g.
"🚫 BREACH: {rule} — {current} vs {limit}"}

### Rule-by-Rule Results
| Rule | Category | Limit | Current | Status | Source |
|------|----------|-------|---------|--------|--------|
| {rule name} | Concentration / Issuer / Sector / Country / Liquidity / Restricted List / ESG / Leverage | {limit or N/A} | {value} | PASS / WATCH / BREACH / NOT EVALUATED | {IPS clause or rule ref} |

### Restricted / Exclusion List Screen
| Security / Issuer | List | Status |
|--------------------|------|--------|
| {name} | Restricted / Watch / ESG Exclusion | CLEAR / BREACH |

### Breach Detail
{For each BREACH: what the rule is, by how much it's breached, and since when if known.
If none, write "No breaches identified."}

### Required Remediation
| Item | Action Required | Owner | Deadline |
|------|-----------------|-------|----------|
| {rule/security} | {specific action, e.g. "trim to ≤3.0%"} | {PM / Compliance / Trading} | {date or "before next trade"} |

### Overall Result
{One line: COMPLIANT / COMPLIANT WITH WATCH ITEMS / NON-COMPLIANT — {N} breach(es)}

### Notes
- IPS / rule source: {document name or "not provided"}
- Data as of: {date}
- Check type: {Pre-trade / Post-trade / Periodic surveillance}

---
⚠️ **This is a compliance-support output, not a final compliance determination.**
Requires review and sign-off by the compliance officer of record before any trade
is executed or blocked on this basis.
```

## Worked Examples

### Example 1 — Post-trade compliance scan with a breach

INPUT:
"Post-trade compliance check for the European Equity fund, 15 Jun 2026. IPS says max single issuer 5%, max sector overweight 10%, no holdings on the firm restricted list. We just bought more Novo Nordisk — now at 6.4%. Financials are at BM+7%. Restricted list: {Company X, Company Y} — neither is currently held."

OUTPUT:
```
## Compliance Check: European Equity Fund — 15 Jun 2026 (Post-Trade)

🚫 BREACH: Single issuer limit — Novo Nordisk at 6.4% vs 5.0% IPS limit.

### Rule-by-Rule Results
| Rule | Category | Limit | Current | Status | Source |
|------|----------|-------|---------|--------|--------|
| Max single issuer | Concentration | 5.0% | 6.4% (Novo Nordisk) | BREACH | IPS |
| Max sector overweight | Sector | 10.0% | +7.0% (Financials) | PASS | IPS |
| Restricted list holdings | Restricted List | 0 holdings | 0 holdings | PASS | Firm restricted list |

### Restricted / Exclusion List Screen
| Security / Issuer | List | Status |
|--------------------|------|--------|
| Company X | Restricted | CLEAR — not held |
| Company Y | Restricted | CLEAR — not held |

### Breach Detail
Novo Nordisk single-issuer concentration is 6.4%, 140bps above the 5.0% IPS limit, following the most recent buy. This is a post-trade breach and requires prompt remediation.

### Required Remediation
| Item | Action Required | Owner | Deadline |
|------|-----------------|-------|----------|
| Novo Nordisk 6.4% | Trim to ≤5.0% | PM / Trading | Before next trading day close |

### Overall Result
NON-COMPLIANT — 1 breach (single issuer limit).

### Notes
- IPS / rule source: European Equity Fund IPS (as referenced by user)
- Data as of: 15 Jun 2026
- Check type: Post-trade

---
⚠️ **This is a compliance-support output, not a final compliance determination.**
Requires review and sign-off by the compliance officer of record before any trade
is executed or blocked on this basis.
```

### Example 2 — Pre-trade check, all clear

INPUT:
"Pre-trade check before we buy 2% of the Balanced Fund in a new EM bond. Mandate caps EM exposure at 15%, currently at 12%. Country limit for any single EM country is 5%; this bond is Brazil, currently 3% Brazil exposure. Not on any exclusion list."

OUTPUT:
```
## Compliance Check: Balanced Fund — Pre-Trade (proposed +2% EM bond, Brazil)

No breaches identified — trade appears within mandate limits.

### Rule-by-Rule Results
| Rule | Category | Limit | Current (pro forma) | Status | Source |
|------|----------|-------|---------------------|--------|--------|
| Max EM exposure | Sector/Region | 15.0% | 14.0% (12% + 2%) | PASS | Mandate |
| Max single EM country | Country | 5.0% | 5.0% (3% + 2%, Brazil) | WATCH — at limit | Mandate |
| Exclusion list | Restricted List | N/A | Not on list | PASS | Firm exclusion list |

### Restricted / Exclusion List Screen
| Security / Issuer | List | Status |
|--------------------|------|--------|
| Proposed Brazil EM bond | Exclusion | CLEAR |

### Breach Detail
No breaches identified.

### Required Remediation
| Item | Action Required | Owner | Deadline |
|------|-----------------|-------|----------|
| Brazil country exposure at 5.0% (at limit) | Monitor — any further Brazil addition would breach | PM | Ongoing |

### Overall Result
COMPLIANT WITH WATCH ITEMS — Brazil country exposure would sit exactly at the 5.0% limit post-trade, leaving no headroom.

### Notes
- IPS / rule source: Balanced Fund mandate (as referenced by user)
- Data as of: pre-trade, same day
- Check type: Pre-trade

---
⚠️ **This is a compliance-support output, not a final compliance determination.**
Requires review and sign-off by the compliance officer of record before any trade
is executed or blocked on this basis.
```

## Rule Category Reference (Secondary Reference)

| Category | Typical rule examples |
|----------|----------------------|
| Concentration | Max single issuer/security, max top-N holdings |
| Sector / Country | Max overweight vs. benchmark, max absolute exposure |
| Liquidity | Max % in securities beyond a liquidity tier, days-to-liquidate limits |
| Restricted List | Firm-wide trading restrictions (M&A, MNPI, litigation) |
| ESG / Exclusions | Sector exclusions (tobacco, thermal coal, controversial weapons), ESG score floors |
| Leverage / Derivatives | Gross/net leverage caps, notional derivative exposure limits, counterparty limits |
| Structured Product | CLO/ABS-specific tests — see /skills/clo-deal-review for OC/IC test detail |

| If the user provides... | Do this |
|--------------------------|---------|
| A full IPS document | Extract every quantitative rule before evaluating |
| Only a few limits | Evaluate those; mark all other categories "NOT EVALUATED — rule not provided" |
| A proposed trade (pre-trade) | Compute pro forma exposure (current + trade) before evaluating each rule |
| No restricted/exclusion list given | State "NOT EVALUATED — no restricted list provided," don't assume clear |
