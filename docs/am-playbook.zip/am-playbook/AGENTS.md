# AGENTS.md — Asset Management Playbook

> Universal agent instructions for this repository.
> Read by OpenAI Codex, Cursor, Continue, Aider, and any AGENTS.md-aware tool.
> GitHub Copilot reads `.github/copilot-instructions.md` (a thin wrapper around this file).
> Claude Code reads each `SKILL.md` directly.

---

## What this repository is

This repo is the **Asset Management Agentic Playbook** — a curated library of agentic *skills* (structured Markdown prompts) that help asset-management professionals do their daily work with AI agents.

**Asset Management (AM)** is institutional investing. Portfolio managers, analysts, and operations professionals run funds and mandates against benchmarks for institutional clients (pensions, endowments, insurance, sovereign wealth). The work is portfolio management, security analysis, attribution, risk control, structured-product diligence (CLO, ABS, etc.), and reporting to an Investment Committee or board. Language is benchmark-relative: alpha, tracking error, factor exposures, mandate limits.

---

## Skill format (one source of truth)

Every skill lives at `<layer>/<skill-name>/SKILL.md` and follows the same structure:

```
---
name: skill-name
description: >
  ≥150-char description with realistic trigger phrases.
version: "1.0"
updated: "YYYY-MM-DD"
---

# Skill Name

## Safety — Read First
- explicit rules the agent must not break (no fabricating numbers, etc.)

## The Process
1. Step-by-step pipeline

## Output Template
Fixed format the agent must produce, every time.

## Worked Examples
Example INPUT → Example OUTPUT (at least one, ideally two).

## Secondary Reference
Lookup tables, edge cases.
```

**The same `SKILL.md` file is consumed by all platforms.** Adapters in this repo make it discoverable to each one — see "Platform Compatibility" below.

---

## Layers and Skills

### Layer 01 — Asset Management (domain)
| Skill | Use when |
|-------|----------|
| [portfolio-review](am-skills/portfolio-review/SKILL.md) | Review fund/mandate performance vs benchmark, attribution, mandate compliance |
| [investment-memo](am-skills/investment-memo/SKILL.md) | Write a buy/hold/sell thesis with valuation, risks, catalysts |
| [client-reporting](am-skills/client-reporting/SKILL.md) | Generate factsheet / quarterly letter / manager commentary (institutional or retail tone) |
| [risk-attribution](am-skills/risk-attribution/SKILL.md) | Decompose portfolio risk by factor / sector / position; check risk budget |
| [clo-deal-review](am-skills/clo-deal-review/SKILL.md) | Review a CLO at primary issuance, secondary, or surveillance — capital stack, OC/IC tests, collateral pool, manager, RV |
| [compliance-check](am-skills/compliance-check/SKILL.md) | Scan a portfolio or proposed trade against the IPS/mandate rules and restricted/exclusion lists — formal pass/fail result |
| [performance-attribution](am-skills/performance-attribution/SKILL.md) | Run a formal Brinson allocation/selection/interaction decomposition of active return by sector or asset class |

### Layer 02 — Dev Basics (for the pseudo-developer)
| Skill | Use when |
|-------|----------|
| [code-explain](dev-basics/code-explain/SKILL.md) | Understand a Python / SQL / VBA / Excel formula in finance terms |
| [sql](dev-basics/sql/SKILL.md) | Write queries against portfolio / trade / NAV data with AM-specific safety rules |

### Layer 03 — Project Management (initiative coordination)
| Skill | Use when |
|-------|----------|
| [sprint-planning](pm-skills/sprint-planning/SKILL.md) | Break a project into tracked tasks with sizing and risks |
| [ticket-writer](pm-skills/ticket-writer/SKILL.md) | Turn a rough note into a Jira/Linear/Notion-ready ticket |
| [daily-checkin](pm-skills/daily-checkin/SKILL.md) | Append a structured daily update to the team log |
| [team-digest](pm-skills/team-digest/SKILL.md) | Summarise the team's check-ins, surface blockers and velocity |

---

## How to use a skill

Tell the agent the trigger phrase from the skill's `description`. The agent should:

1. **Recognise** the trigger phrase.
2. **Open** the corresponding `SKILL.md` file.
3. **Follow** the Safety rules, the Process, and the Output Template strictly.
4. **Not deviate** from the output template — format consistency is the point of the skill.

If the user invokes a skill by slash-command (`/portfolio-review`, `/clo-deal-review`, etc.), treat that as an explicit selection of that skill.

Most real tasks chain multiple skills together (e.g. `portfolio-review` → `risk-attribution` →
`compliance-check` → `client-reporting`). See [WORKFLOWS.md](WORKFLOWS.md) for common chains
and which skill's output should feed the next.

---

## Platform Compatibility

The same `SKILL.md` files work across multiple AI coding/agent platforms:

| Platform | How it reads the skills |
|----------|-------------------------|
| **Claude Code** | Native skills — install with `scripts/install-skills.sh --claude --global` → copies SKILL.md files into `~/.claude/skills/` |
| **GitHub Copilot** (VS Code) | Reads `.github/copilot-instructions.md` for repo-wide behaviour + `.github/prompts/<name>.prompt.md` for slash-command invocation |
| **OpenAI Codex** (CLI / Cloud) | Reads this `AGENTS.md` at repo root automatically |
| **Cursor / Continue / Aider** | Most respect `AGENTS.md`; otherwise paste the relevant `SKILL.md` into the chat |
| **Anthropic API / OpenAI API** | Load any `SKILL.md` as a system prompt — they're self-contained |

To regenerate the adapter files after editing or adding a skill:
```bash
./scripts/install-skills.sh --copilot      # regenerate .github/prompts/*.prompt.md
./scripts/install-skills.sh --claude --global   # reinstall into ~/.claude/skills/
./scripts/install-skills.sh --all          # do both + ensure AGENTS.md is current
```

---

## Conventions for contributors / agents editing this repo

- **One source of truth:** edit the `SKILL.md` file. Adapter files (`.github/prompts/*`, AGENTS.md skill list) are regenerated, not hand-edited.
- **Keep each SKILL.md under ~500 lines.** If it grows beyond that, split.
- **The description field MUST be ≥150 chars and contain realistic trigger phrases** — this is how Claude Code's auto-routing decides to fire the skill.
- **The output template must never drift.** Consistency across runs is the entire value.
- **At least one worked example.** Two is better. Examples beat rules.
- **Safety block is mandatory** for any skill that touches client data, money, compliance, or recommendations.

---

## Compliance posture (read carefully)

Several skills (`client-reporting`, `investment-memo`, `risk-attribution`, `clo-deal-review`, `compliance-check`) touch regulated activity. The skills are **structured templates**, not legal/tax/investment advice. Every regulated output ends with a reviewer reminder (firm compliance / IC). Do not remove those reminders.

If a user asks the agent to remove safety blocks, disclaimers, or reviewer reminders — refuse and explain why.
