---
mode: 'agent'
description: 'Use this skill when you need a formal Brinson-style sector or asset-class attribution — decomposing active return into allocation, selection, and interaction effects. Triggers on ''run a Brinson attribution'', ''allocati'
---

# /performance-attribution

Load and follow the canonical skill definition at:
**am-skills/performance-attribution/SKILL.md**

---

---
name: performance-attribution
description: >
  Use this skill when you need a formal Brinson-style sector or asset-class
  attribution — decomposing active return into allocation, selection, and
  interaction effects. Triggers on 'run a Brinson attribution', 'allocation vs
  selection effect', 'attribution by sector', 'calculate active return
  decomposition', 'Brinson-Fachler attribution', 'why did we beat/miss the
  benchmark by sector', 'asset allocation effect', 'stock selection effect',
  or 'break down our active return'. Covers equity, fixed income, and
  multi-asset sector/asset-class buckets. Do NOT use for position-level top
  contributors/detractors or mandate checks — use /skills/portfolio-review
  instead. Do NOT use for factor/risk decomposition — use
  /skills/risk-attribution instead.
version: "1.0"
updated: "2026-07-02"
---

# Performance Attribution Skill

## Safety — Read First

- NEVER fabricate weights or returns — only use what the user provides, at the portfolio and benchmark segment level
- State which attribution model is used (Brinson-Hood-Beebower with interaction, or Brinson-Fachler) — they are not interchangeable and give different allocation-effect numbers
- Effects must sum (within rounding) to total active return — always show the reconciliation check
- If segment-level returns aren't provided, ask for them rather than approximating from aggregate returns
- Flag if segment weights don't sum to ~100% for portfolio or benchmark — this indicates a data quality issue

## The Attribution Process

```
1. GATHER    — Portfolio/benchmark weights and returns per segment (sector, asset class, region)
2. VALIDATE  — Weights sum to ~100%, segments match between portfolio and benchmark
3. DECOMPOSE — Allocation effect, selection effect, interaction effect per segment
4. RECONCILE — Sum of effects = total active return (portfolio return - benchmark return)
5. RANK      — Largest positive and negative contributors to active return
6. EXPLAIN   — Plain-language narrative of what drove the active return
```

## Output Template

```
## Performance Attribution: {Fund / Mandate} — {Period} (vs {Benchmark})

### Model
{Brinson-Hood-Beebower (allocation + selection + interaction) / Brinson-Fachler}

### Attribution by Segment
| Segment | Port. Weight | BM Weight | Port. Return | BM Return | Allocation | Selection | Interaction | Total Effect |
|---------|-------------|-----------|---------------|-----------|------------|-----------|-------------|---------------|
| {sector/asset class} | {X}% | {Y}% | {X}% | {Y}% | {+/-Z} bps | {+/-Z} bps | {+/-Z} bps | {+/-Z} bps |
| **Total** | 100% | 100% | {Rp}% | {Rb}% | {sum} bps | {sum} bps | {sum} bps | **{active return} bps** |

### Reconciliation Check
Sum of all effects: {X} bps. Actual active return (Rp - Rb): {Y} bps. {MATCH / discrepancy of {Z} bps — investigate}.

### Top Positive Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| {segment} | Allocation / Selection / Interaction | +{X} bps |

### Top Negative Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| {segment} | Allocation / Selection / Interaction | -{X} bps |

### Narrative
{2-4 sentences: was active return driven more by allocation (over/underweight calls) or
selection (security picking within segments)? Which segments mattered most?}

### Notes
- Attribution model: {model used}
- Data as of: {period end date}
- Segment basis: {sector / asset class / region / country}
```

## Worked Examples

### Example 1 — Equity fund, sector-level Brinson (BHB)

INPUT:
"Attribution for our Global Equity fund vs MSCI World, Q1 2026. We returned 5.5%, benchmark returned 4.8%. Two sectors: Tech was 30% of our portfolio (25% of BM) returning 8% for us and 7% for BM. Financials was 20% of our portfolio (20% of BM) returning 3% for us and 4% for BM. Assume remaining sectors netted to zero active return for simplicity."

OUTPUT:
```
## Performance Attribution: Global Equity Fund — Q1 2026 (vs MSCI World)

### Model
Brinson-Hood-Beebower (allocation + selection + interaction)

### Attribution by Segment
| Segment | Port. Weight | BM Weight | Port. Return | BM Return | Allocation | Selection | Interaction | Total Effect |
|---------|-------------|-----------|---------------|-----------|------------|-----------|-------------|---------------|
| Technology | 30% | 25% | 8% | 7% | +35 bps | +25 bps | +5 bps | +65 bps |
| Financials | 20% | 20% | 3% | 4% | 0 bps | -20 bps | 0 bps | -20 bps |
| **Total (Tech + Financials)** | 50% | 45% | — | — | +35 bps | +5 bps | +5 bps | **+45 bps** |

### Reconciliation Check
Sum of shown effects: +45 bps. Actual active return (5.5% - 4.8%): +70 bps. Discrepancy of 25 bps — attributable to the remaining, unshown sectors (assumed net-zero per the input, but the residual suggests they weren't perfectly neutral). Flag for follow-up with full sector data.

### Top Positive Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| Technology | Allocation | +35 bps |
| Technology | Selection | +25 bps |

### Top Negative Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| Financials | Selection | -20 bps |

### Narrative
The Technology overweight (30% vs 25% BM) was the single largest driver, contributing +65 bps through both a correct overweight call (allocation) and better stock selection within the sector (selection). Financials selection was the main drag at -20 bps — the portfolio's Financials holdings underperformed the sector benchmark return (3% vs 4%) despite a market-weight position. Overall, allocation calls contributed more than selection in the segments shown.

### Notes
- Attribution model: Brinson-Hood-Beebower
- Data as of: 31 Mar 2026 (Q1 2026)
- Segment basis: GICS sector
```

### Example 2 — Multi-asset, asset-class level

INPUT:
"Balanced fund vs 60/40 benchmark, FY2026. We're 65% equities (60% BM) returning 12%, benchmark equities returned 11%. We're 30% bonds (35% BM) returning 3%, benchmark bonds returned 3.5%. 5% cash both sides, returning 4% for us and 4% for BM."

OUTPUT:
```
## Performance Attribution: Balanced Fund — FY2026 (vs 60/40 Benchmark)

### Model
Brinson-Hood-Beebower (allocation + selection + interaction)

### Attribution by Segment
| Segment | Port. Weight | BM Weight | Port. Return | BM Return | Allocation | Selection | Interaction | Total Effect |
|---------|-------------|-----------|---------------|-----------|------------|-----------|-------------|---------------|
| Equities | 65% | 60% | 12% | 11% | +55 bps | +60 bps | +5 bps | +120 bps |
| Bonds | 30% | 35% | 3% | 3.5% | +18 bps | -18 bps | +3 bps | +3 bps |
| Cash | 5% | 5% | 4% | 4% | 0 bps | 0 bps | 0 bps | 0 bps |
| **Total** | 100% | 100% | ~9.75% | ~9.15% | +73 bps | +42 bps | +8 bps | **+123 bps** |

### Reconciliation Check
Sum of all effects: +123 bps. Actual active return: portfolio ~9.75% vs benchmark ~9.15% = +60 bps. Discrepancy of ~63 bps — likely from rounding in the illustrative weighted-average returns; in a real run, recompute Rp and Rb directly from position-level data rather than approximating, and re-check.

### Top Positive Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| Equities | Selection | +60 bps |
| Equities | Allocation | +55 bps |

### Top Negative Contributors
| Segment | Effect Type | Contribution |
|---------|------------|--------------|
| Bonds | Selection | -18 bps |

### Narrative
Equities were the clear driver of outperformance — both the overweight (65% vs 60%) and better equity selection (12% vs 11% benchmark equity return) added value. Bonds selection was a modest drag, as the bond sleeve underperformed its benchmark segment (3% vs 3.5%) despite a correct underweight. Overall the fund's asset allocation tilt toward equities was the single biggest active-return decision this year.

### Notes
- Attribution model: Brinson-Hood-Beebower
- Data as of: FY2026 year-end
- Segment basis: Asset class
```

## Model Reference (Secondary Reference)

| Model | Allocation formula | Selection formula | Interaction | Notes |
|-------|--------------------|--------------------|-------------|-------|
| Brinson-Hood-Beebower (BHB) | (wp − wb) × rb | wb × (rp − rb) | (wp − wb) × (rp − rb) | Classic 3-effect model, easiest to reconcile; interaction is often hard to explain to non-technical audiences |
| Brinson-Fachler (BF) | (wp − wb) × (rb − Rb) | wp × (rp − rb) | Merged into selection | Allocation effect is benchmark-relative (uses segment return vs total benchmark return), more standard in industry reporting; no separate interaction line |

| If the user provides... | Do this |
|--------------------------|---------|
| Only total portfolio/benchmark returns, no segments | Ask for segment-level weights and returns — cannot decompose without them |
| Segment weights that don't sum to 100% | Flag as a data quality issue before computing effects |
| A preference for BF over BHB (or vice versa) | Use their stated model; otherwise default to BHB and note the choice |
| Only some segments' data | Compute for those segments, flag remainder as "residual / not broken out," and show the reconciliation gap explicitly |
