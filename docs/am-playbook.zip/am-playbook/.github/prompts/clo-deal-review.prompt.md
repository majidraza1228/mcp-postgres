---
mode: 'agent'
description: 'Use this skill when reviewing a CLO (Collateralized Loan Obligation) deal — whether at primary issuance, in the secondary market, or for portfolio monitoring. Triggers on ''review this CLO'', ''CLO deal review'', ''CLO t'
---

# /clo-deal-review

Load and follow the canonical skill definition at:
**am-skills/clo-deal-review/SKILL.md**

---

---
name: clo-deal-review
description: >
  Use this skill when reviewing a CLO (Collateralized Loan Obligation) deal —
  whether at primary issuance, in the secondary market, or for portfolio
  monitoring. Triggers on 'review this CLO', 'CLO deal review',
  'CLO tearsheet for', 'check this CLO at issuance', 'CLO primary deal',
  'review CLO equity / mezz / AAA', 'analyse this CLO', 'CLO manager
  review', or 'CLO surveillance check'. Covers the capital structure
  (AAA → equity), collateral pool stats (WARF, WAS, diversity, industry
  concentration), structural tests (OC/IC, par build), MV cushion,
  manager track record, and relative value vs peers. Do NOT use for
  general portfolio review — use /skills/portfolio-review instead. Do NOT
  use for ABS/MBS deals that aren't CLOs — collateral and structure differ.
version: "1.0"
updated: "2026-06-29"
---

# CLO Deal Review Skill

## Safety — Read First

- NEVER fabricate deal stats — WARF, WAS, diversity score, OC/IC test cushion, prices, ratings. Use only what the user / offering memorandum / trustee report provides
- NEVER state a recommendation as a price/yield target without explicit user input
- ALWAYS distinguish PRIMARY (at-issuance, offering memorandum data) from SECONDARY (trustee-report data, post-effective-date) — they require different test framing
- Flag any OC/IC test FAILURE or near-trigger (<50bp cushion) at the top of the output, before everything else
- CCC bucket above 7.5% threshold is a key collateral-quality flag — surface it explicitly
- Manager track record claims must be tied to a specific vintage or composite — do not generalise
- Structural triggers (Reinvestment Period end, Non-Call End, Effective Date) materially change cash flow profile — note where in the deal life cycle this CLO sits
- Distress-related triggers (Event of Default, acceleration, post-reinvestment paydown) are non-recoverable in the same way — surface immediately

## The Review Process

```
1. IDENTIFY     — Deal name, manager, vintage, jurisdiction, currency, life-cycle stage
2. STRUCTURE    — Capital stack (AAA → equity), thickness, attachment/detachment, ratings
3. COLLATERAL   — Pool stats: WARF, WAS, diversity, industry top-3, top-10 obligors, CCC%
4. TESTS        — OC and IC test status per tranche, cushion, recent par build/loss
5. MANAGER      — Track record across vintages, AUM, team stability, style
6. RV / VIEW    — Relative value vs peers, recommendation, risks, monitoring plan
```

## Output Template

```
## CLO Deal Review: {Deal Name} — {Series} ({Manager}, {Vintage})

{FLAG — any test failure, near-trigger, or distress signal goes here BEFORE anything else}

**Deal type:** {New issue / Refi / Reset / Secondary purchase}
**Life-cycle stage:** {Pre-pricing / Ramp / Reinvestment / Post-reinvestment / Amortising}
**Currency / Jurisdiction:** {USD / EUR — US BSL / EU BSL / Middle-market}
**Pricing date / As-of:** {date}
**Trustee report as-of:** {date — if secondary/surveillance}

---

### Capital Structure
| Tranche | Rating (S&P / Moody's) | Size ($M) | % Notional | Subord (%) | Coupon / Spread | Px (if 2ndy) |
|---------|------------------------|-----------|------------|------------|-----------------|--------------|
| A-1 (AAA) | | | | | SOFR + bps | |
| A-2 | | | | | | |
| B (AA) | | | | | | |
| C (A) | | | | | | |
| D (BBB) | | | | | | |
| E (BB) | | | | | | |
| F (B) | | | | | | |
| Subordinated / Equity | NR | | | 0% (first loss) | Residual | |

### Collateral Pool Summary
| Metric | Value | Threshold / Benchmark | Status |
|--------|-------|----------------------|--------|
| Pool size ($M) | | — | — |
| Number of obligors | | Typical 150-300 (BSL) | |
| Diversity Score (Moody's) | | Typical 60-90 | |
| WARF (Moody's) | | Test trigger {e.g. 2900} | OK / WATCH / FAIL |
| WAS (Weighted Avg Spread) | | Test trigger {e.g. 3.40%} | |
| WARR (Weighted Avg Recovery Rate) | | | |
| Weighted Avg Life (WAL) | | Test trigger {e.g. 7.5y} | |
| % Cov-Lite | | | |
| % Second Lien | | Typical limit 5-10% | |
| % CCC-rated bucket | | **Trigger 7.5%** (typical US BSL) | **OK / WATCH / FAIL** |
| % Defaulted | | | |
| Top-3 industries (%) | | Typical limit 12-15% per | |
| Top-10 obligors (% of pool) | | | |
| Largest single obligor (%) | | Typical limit 2-2.5% | |

### Structural Tests (Post-Effective Date / Surveillance)
| Test | Tranche | Trigger | Actual | Cushion | Status |
|------|---------|---------|--------|---------|--------|
| OC Test | A/B | {e.g. 124.5%} | {e.g. 127.1%} | +260bp | OK |
| OC Test | C | | | | |
| OC Test | D | | | | |
| OC Test | E (junior-most) | | | | |
| IC Test | A/B | | | | |
| IC Test | E | | | | |
| Reinvestment OC (if applicable) | | | | | |
| Interest Diversion Test | | | | | |

> Flag any cushion <50bp as WATCH; any failure as FAIL with diversion / payment consequence.

### Recent Performance & Migration (Surveillance — if applicable)
| Metric | Last Period | This Period | Δ |
|--------|-------------|-------------|---|
| Par build / (loss) | | | |
| Defaults (LTM, $M / count) | | | |
| Recoveries (LTM) | | | |
| Downgrade migration (% of pool) | | | |
| CCC bucket | | | |
| Equity distribution (latest) | | | |

### Manager Profile
- **Firm AUM (CLO platform):** ${X}bn across {N} deals
- **Vintages:** {range, e.g. 2014-2026}
- **Equity-tier track record:** {Composite IRR if available — note vintage dispersion}
- **Style:** {par buyer / discount / hybrid; opportunistic vs steady}
- **Team continuity:** {PM / credit team tenure}
- **Notable strengths / concerns:** {bullet}

### Relative Value
| Tranche | This Deal | Peer Median (Last 30d) | Comment |
|---------|-----------|------------------------|---------|
| AAA spread | SOFR + {X} | SOFR + {Y} | Tight / Cheap / In line |
| BB spread | SOFR + {X} | SOFR + {Y} | |
| Equity (if priced) | {arb / NPV / par} | | |

### Recommendation
**{BUY / ADD / HOLD / REDUCE / SELL / PASS}**
Tranche(s): {specify}
Conviction: {HIGH / MEDIUM / LOW}
Sizing context: {single deal cap, manager cap, capital structure cap if mandated}

### Key Risks
| Risk | Likelihood | Impact | Mitigation / Monitor |
|------|------------|--------|---------------------|
| Loan defaults rise faster than recovery | | | Monitor CCC migration monthly |
| Manager turnover or style drift | | | Track team announcements |
| Refi / reset risk (if approaching NC end) | | | Note NC end date |
| {Macro / sector} | | | |

### Monitoring Plan
- Frequency: {Monthly / Quarterly}
- Triggers for re-review: {OC cushion <100bp, CCC > 6%, manager turnover, etc.}
- Next review: {date}

### Notes & Data Sources
- Offering memorandum / Trustee report dated: {}
- Intex / Trepp / Bloomberg CLOS data as of: {}
- Manager call: {date / N/A}

---
*Internal CLO research note. Not investment advice. Test thresholds and definitions vary by indenture — always reconcile to the specific deal documents.*
```

## Worked Examples

### Example 1 — Primary new-issue review

INPUT:
"Review the primary new-issue CLO from Acme Credit Management — Acme CLO XII, USD $400M, US BSL. AAA at SOFR+135. BB at SOFR+700. Equity arb ~14% modelled. Pool: 250 obligors, WARF 2820, WAS 3.55%, Diversity 78, CCC 4.5%, second lien 4%, top industry Software at 13%. Pricing this Thursday. Acme has 11 prior deals, 2014-2025, top-quartile manager. 5-year reinvestment, 2-year non-call."

OUTPUT:
```
## CLO Deal Review: Acme CLO XII — Series 2026 (Acme Credit Management, 2026 vintage)

No structural flags — clean profile at issuance. Top-industry concentration (Software 13%) at watch level; confirm against indenture limit.

**Deal type:** New issue (primary)
**Life-cycle stage:** Pre-pricing — to ramp post-close
**Currency / Jurisdiction:** USD — US BSL
**Pricing date:** Thursday this week
**Trustee report as-of:** N/A (primary)

---

### Capital Structure
| Tranche | Rating | Size ($M) | % Notional | Subord (%) | Spread |
|---------|--------|-----------|------------|------------|--------|
| A-1 (AAA) | AAA | ~250 | ~62.5% | ~37.5% | SOFR + 135 |
| Mezz tranches | AA → B | (per OM) | | | |
| BB | BB | (per OM) | | | SOFR + 700 |
| Subordinated / Equity | NR | (per OM) | | 0% | Residual — arb ~14% modelled |

> Confirm full tranche sizing/spreads against final offering memorandum.

### Collateral Pool Summary (Target Portfolio / Ramp)
| Metric | Value | Threshold | Status |
|--------|-------|-----------|--------|
| Number of obligors (target) | 250 | Typical 150-300 | OK |
| Diversity Score | 78 | Typical 60-90 | OK |
| WARF (Moody's) | 2820 | Typical trigger ~2900 | OK — ~80bp cushion to typical trigger |
| WAS | 3.55% | Typical trigger ~3.40% | OK |
| % CCC | 4.5% | 7.5% (typical US BSL) | OK — 300bp cushion |
| % Second Lien | 4% | Typical 5-10% limit | OK |
| Top industry — Software | 13% | Typical 12-15% limit | **WATCH** — at the higher end of typical limit; confirm specific indenture cap |

### Structural Tests
At pricing — tests will be set per indenture. No surveillance data yet.
| Test | Note |
|------|------|
| OC / IC triggers | To be confirmed from indenture — typical AAA OC ~124%, BBB OC ~108% |
| Reinvestment period | 5 years (standard US BSL) |
| Non-call period | 2 years (standard) |

### Manager Profile
- **AUM (CLO platform):** Acme Credit Management — 11 prior US BSL deals (2014-2025) plus this one (12th)
- **Track record (user-asserted):** Top-quartile manager
- **Vintages spanned:** 2014-2025 — 11 years; managed across a full cycle including 2020 COVID stress
- **Team continuity:** Confirm with manager (not in input)
- **Style:** Confirm (par buyer vs discount; opportunistic vs steady) — user did not specify

### Relative Value
| Tranche | This Deal | Peer Median (recent US BSL primary) | Comment |
|---------|-----------|-------------------------------------|---------|
| AAA | SOFR + 135 | (confirm — recent comparable trades) | Confirm vs same-week comps |
| BB | SOFR + 700 | | Confirm vs same-week comps |
| Equity modelled IRR | ~14% | Recent issuance equity arbs typically low-to-mid teens | In range; sensitive to ramp execution and loan defaults |

> User did not provide peer comparable spreads — RV is indicative only.

### Recommendation
**ADD (subject to RV confirmation and tranche selection)**
Tranche(s): To be specified — equity arb at ~14% is in the range; BB at +700 is competitive subject to peer comparables.
Conviction: MEDIUM
Sizing context: Confirm against single-deal cap and Acme platform cap.

### Key Risks
| Risk | Likelihood | Impact | Mitigation / Monitor |
|------|------------|--------|---------------------|
| Loan default cycle accelerates during ramp | M | H | Monitor monthly CCC migration; manager's defensive posturing |
| Software-sector concentration at the cap | M | M | Confirm specific indenture limit; monitor industry test cushion |
| Ramp pricing weaker than indicated | M | M | Track ramp vs target weighted-average price over first 3 months |
| Reset/refi risk at NC end (2yr) | L (long-dated) | M | Note for 2028 review |

### Monitoring Plan
- Frequency: Monthly during ramp; quarterly thereafter
- Triggers for re-review: CCC > 6%, OC cushion < 100bp, manager team announcement, par build turning negative
- Next review: Post-effective-date (typically 4-6 months post-pricing)

### Notes & Data Sources
- Offering memorandum: confirm latest red
- Intex / Bloomberg CLOS: pull post-ramp pool
- Manager call: recommended pre-pricing to confirm style/positioning

---
*Internal CLO research note. Not investment advice. Test thresholds and definitions per indenture.*
```

### Example 2 — Surveillance / secondary review of a deal in stress

INPUT:
"Surveillance review of Beacon CLO VII (Beacon Capital, 2021 vintage, USD $450M). Trustee report 31-May-2026. Pool WARF 3120, WAS 3.65%, Diversity 71, CCC bucket 8.2%, defaults 1.9% of par, top industry Healthcare 14%. OC tests: AAA/AA at 125.8% (trigger 124.0%, +180bp cushion). BBB OC at 109.2% (trigger 108.5%, +70bp). BB OC at 105.8% (trigger 106.0% — failed by 20bp). Par lost 60bp this quarter. Reinvestment ends Apr-2027. Question: hold or sell our BB position purchased at 92."

OUTPUT:
```
## CLO Deal Review: Beacon CLO VII — Surveillance (Beacon Capital, 2021 vintage)

⚠️ TEST FAILURE: BB OC Test FAILED — actual 105.8% vs trigger 106.0% (−20bp). Interest diversion to junior OC cure expected; equity distribution will be impaired.
⚠️ WATCH: CCC bucket 8.2% — ABOVE typical 7.5% threshold. Confirm specific indenture trigger; excess CCC carried at lower of MV / Moody's recovery for OC numerator.
⚠️ WATCH: BBB OC cushion +70bp — thin; one more quarter of par loss could pressure.
⚠️ WATCH: Top industry Healthcare 14% — confirm vs indenture limit (typical 12-15%).

**Deal type:** Secondary holding — surveillance review
**Life-cycle stage:** Reinvestment (ends Apr-2027 — ~10 months remaining)
**Currency / Jurisdiction:** USD — US BSL
**Trustee report as-of:** 31-May-2026

---

### Collateral Pool Summary
| Metric | Value | Threshold / Benchmark | Status |
|--------|-------|----------------------|--------|
| Pool size | $450M | — | — |
| Diversity | 71 | 60-90 typical | OK |
| WARF | 3120 | Typical trigger ~2900 | **Likely above WARF trigger — confirm; OC numerator impacted** |
| WAS | 3.65% | Typical trigger ~3.40% | OK — generating excess spread |
| CCC bucket | 8.2% | **7.5% typical trigger** | **WATCH — confirm exact indenture trigger; excess CCC haircut applies** |
| Defaulted | 1.9% | | Above peer norm |
| Top industry (Healthcare) | 14% | Typical limit 12-15% | **WATCH — at upper end** |

### Structural Tests
| Test | Trigger | Actual | Cushion | Status |
|------|---------|--------|---------|--------|
| AAA/AA OC | 124.0% | 125.8% | +180bp | OK |
| BBB OC | 108.5% | 109.2% | +70bp | **WATCH — thin** |
| **BB OC** | **106.0%** | **105.8%** | **−20bp** | **FAIL — interest diversion active** |

**Consequence of BB OC failure:**
- Interest cash flows that would have paid BB and below (incl. equity) are diverted to pay down senior notes until the test cures
- BB notes still receive interest first, but the equity distribution this period is the at-risk item
- Manager will be incentivised to trade defensively to cure (par building); some flexibility constrained by reinvestment ending in ~10 months

### Recent Performance & Migration
| Metric | This Period | Comment |
|--------|-------------|---------|
| Par build / (loss) | (60bp) | Negative quarter — driver of test cushion erosion |
| Defaults (1.9%) | Elevated | Above peer norm for vintage |
| CCC bucket | 8.2% | Trending up — likely above trigger |

### Manager Profile
Beacon Capital — 2021 vintage. Recommend pulling manager's full vintage track record to compare this deal vs Beacon's other deals (is this a deal-specific issue or platform-wide?). Reinvestment ending in ~10 months reduces manager's ability to trade out of weak credits — late-stage reinvestment with weak metrics is a known risk pattern.

### Relative Value — Hold vs Sell the BB at 92
**Hold case:**
- Cash bond — even with interest diversion, BB still receives coupon (it's lower-tier OC failing, but BB itself is the BB tranche being protected; verify exact waterfall in this deal — in some structures BB OC failure diverts away from EQUITY first, with BB still paid)
- Reinvestment ends in 10 months → forced amortisation begins → BB will start receiving principal paydowns at par from senior amortisation cascade
- If par held flat from here, BB likely money-good; 92 → par on amortisation = upside

**Sell case:**
- Test failures cascading from junior up — next quarter could test BBB cushion (currently +70bp)
- Manager has limited time to cure inside reinvestment
- Liquid secondary market for BB CLOs is thinner in stress; sell now vs later may be better execution
- Continued par loss compounds — 60bp lost this quarter; another 60bp would breach BBB

### Recommendation
**HOLD with conditions, OR partial sale (e.g. 50% trim)**
- Conviction: LOW-MEDIUM
- Conditions for full sell: BBB OC cushion drops below +40bp at next trustee report; CCC bucket > 9%; par loss > 100bp next quarter
- Conditions for re-add: par builds back; CCC declines below 7%; BB OC cures

### Key Risks
| Risk | Likelihood | Impact | Mitigation / Monitor |
|------|------------|--------|---------------------|
| Cascading OC test failures up the structure | M | H | Watch BBB cushion monthly |
| CCC bucket continues climbing → larger OC numerator haircut | M | H | Monthly CCC migration tracking |
| Manager forced into amortisation before recovery | M | M | Reinvestment ends Apr-2027 |
| BB recovery weaker than par on amortisation | L-M | M | Underlying loan default + recovery assumptions |

### Monitoring Plan
- Frequency: **Monthly** trustee reports (elevated from quarterly given stress)
- Re-review triggers: any further OC test failure, CCC > 9%, manager team change
- Next review: 30 days

### Notes & Data Sources
- Trustee report 31-May-2026 (user-provided)
- Recommend pulling Intex / Bloomberg CLOS for peer 2021-vintage CCC and OC cushion percentiles
- Direct call with Beacon manager warranted

---
*Internal surveillance note. The OC waterfall and exact diversion mechanics depend on the specific Beacon CLO VII indenture — confirm before action.*
```

## Reference (Secondary)

### CLO life-cycle stages
| Stage | What it means | Implication |
|-------|---------------|-------------|
| Pre-pricing / Warehouse | Manager accumulating loans; deal not yet priced | Indicative pool; risk = ramp execution and arb compression |
| Ramp | Post-pricing, manager building to target portfolio | First 4-6 months; effective date triggers tests |
| Reinvestment Period | Manager can buy/sell loans; principal proceeds reinvested | Typical 5 years; most flexibility |
| Post-Reinvestment / Amortising | Senior notes paid down with principal proceeds | Equity / BB / B receive return of capital via cascade |

### Key tests in plain English
| Test | What it measures | Why it matters |
|------|------------------|----------------|
| **OC (Overcollateralisation)** | Collateral par / tranche par | If fails, interest cash flows diverted to pay senior notes; equity is first to feel it |
| **IC (Interest Coverage)** | Collateral interest / tranche interest | If fails, same diversion |
| **CCC bucket test** | % of pool rated CCC+ or lower | Excess CCC haircut applied to OC numerator (lower of MV / Moody's recovery) |
| **WARF** | Weighted Average Rating Factor (Moody's) | Aggregate credit-quality score; lower = higher quality |
| **WAS** | Weighted Average Spread of pool | Excess spread = first defence against losses |
| **Diversity Score** | Moody's measure of obligor/industry diversification | Higher = better |
| **WAL** | Weighted Average Life of pool | Must stay inside indenture cap |

### Common indenture trigger ranges (US BSL — typical; always verify per deal)
| Test | Typical value |
|------|---------------|
| AAA OC | 120-126% |
| BBB OC | 106-110% |
| BB OC | 104-108% |
| WARF | 2800-3000 |
| WAS | 3.40-3.60% |
| Diversity | 60-90 |
| CCC bucket | 7.5% (excess CCC haircut applies) |
| Single industry max | 12-15% (top 3 industries) |
| Single obligor max | 2.0-2.5% |
| Second lien max | 5-10% |
| Cov-lite | Typically no cap (most loans are cov-lite) |

### When to stop and ask
- Indenture limits not provided → flag and use "typical" ranges with explicit caveat
- Manager track record asserted without numbers → ask for composite IRR / loss data
- "Peer median" requested but no comparables provided → flag RV section as indicative
- Test cushion not provided → calculate from trigger + actual; flag if either is missing
