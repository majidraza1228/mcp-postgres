---
mode: 'agent'
description: 'Use this skill when reviewing a fund, mandate, or portfolio''s performance, holdings, attribution, or positioning. Triggers on ''review the portfolio'', ''how are we doing vs benchmark'', ''portfolio check'', ''attributi'
---

# /portfolio-review

Load and follow the canonical skill definition at:
**am-skills/portfolio-review/SKILL.md**

---

---
name: portfolio-review
description: >
  Use this skill when reviewing a fund, mandate, or portfolio's performance,
  holdings, attribution, or positioning. Triggers on 'review the portfolio',
  'how are we doing vs benchmark', 'portfolio check', 'attribution analysis',
  'top contributors and detractors', 'review this month's performance', 'flag
  any mandate breaches', 'where are we versus target weights', 'performance
  review for the IC', or 'check our sector weights'. Handles equity, fixed
  income, and multi-asset portfolios. Do NOT use for writing an investment
  thesis on a specific position — use /skills/investment-memo instead.
  Do NOT use for writing client letters — use /skills/client-reporting instead.
  Do NOT use for formal Brinson allocation/selection/interaction decomposition
  — use /skills/performance-attribution instead. Do NOT use for a formal
  pass/fail rule-by-rule compliance scan — use /skills/compliance-check instead.
version: "1.0"
updated: "2026-06-13"
---

# Portfolio Review Skill

## Safety — Read First

- NEVER fabricate performance numbers — only use what the user provides
- If the user pastes a data export, note any gaps or ambiguities before drawing conclusions
- Flag any mandate breach immediately at the top of the output, before the rest of the review
- If compliance-sensitive data is pasted (client names, account numbers), note it and exclude from output

## The Review Process

```
1. IDENTIFY  — Fund name, benchmark, review period, currency
2. PERFORMANCE — Returns vs benchmark (absolute and relative), key stats
3. ATTRIBUTION — Top contributors and detractors by position and sector
4. POSITIONING  — Current weights vs target weights or benchmark
5. MANDATE     — Check limits and flag any breach or watch item
6. ACTIONS     — Recommended adjustments with rationale
```

## Output Template

```
## Portfolio Review: {Fund / Mandate} — {Period}

{MANDATE BREACH FLAG — if any, put it here before anything else}

### Performance Summary
| Metric | Portfolio | Benchmark | +/- |
|--------|-----------|-----------|-----|
| Return (period) | {X}% | {Y}% | {+/-Z} bps |
| Return (YTD) | | | |
| Volatility (ann.) | | | |
| Sharpe Ratio | | | |
| Max Drawdown (period) | | | |

### Attribution — Top Contributors
| Position | Sector | Avg Weight | Contribution |
|----------|--------|------------|-------------|
| {name} | {sector} | {X}% | +{Y} bps |

### Attribution — Top Detractors
| Position | Sector | Avg Weight | Contribution |
|----------|--------|------------|-------------|
| {name} | {sector} | {X}% | -{Y} bps |

### Positioning vs Target / Benchmark
| Segment | Portfolio | Target / BM | +/- | Status |
|---------|-----------|-------------|-----|--------|
| {Sector or Asset Class} | {X}% | {Y}% | {+/-Z}% | OK / WATCH / BREACH |

### Mandate Checks
| Check | Limit | Current | Status |
|-------|-------|---------|--------|
| {e.g. Max single name} | {X}% | {Y}% | OK / WATCH / BREACH |

### Summary
{2-3 sentences. What drove performance, what's notable in positioning, overall picture.}

### Recommended Actions
1. {Action — with one-line rationale}
2. {Action}

### Open Questions for IC / PM
- {Question if any — otherwise "None"}
```

## Worked Example

### Example 1 — Monthly equity review

INPUT:
"Review the Global Equity fund for May 2026. We returned -1.2% vs MSCI World which returned -0.8%. Our biggest drag was Nvidia (-0.4% contribution) and ASML (-0.3%). Our best performer was our underweight China which added +0.2%. We're 8% overweight US Tech vs benchmark. Mandate limit is 10% overweight in any single sector."

OUTPUT:
```
## Portfolio Review: Global Equity — May 2026

### Performance Summary
| Metric | Portfolio | Benchmark (MSCI World) | +/- |
|--------|-----------|------------------------|-----|
| Return (May 2026) | -1.2% | -0.8% | -40 bps |
| Relative return | | | -40 bps underperformance |

### Attribution — Top Contributors
| Position | Sector | Contribution |
|----------|--------|-------------|
| China underweight | EM / Asia | +20 bps |

### Attribution — Top Detractors
| Position | Sector | Contribution |
|----------|--------|-------------|
| Nvidia | US Technology | -40 bps |
| ASML | European Technology | -30 bps |

### Positioning vs Benchmark
| Segment | Portfolio | BM | +/- | Status |
|---------|-----------|----|----|--------|
| US Technology | BM + 8% | — | +8% | WATCH (limit: +10%) |

### Mandate Checks
| Check | Limit | Current | Status |
|-------|-------|---------|--------|
| Max sector overweight | +10% | +8% US Tech | WATCH — 2% headroom |

### Summary
May was a -40bps month relative to MSCI World, driven primarily by Technology exposure (Nvidia, ASML) amid sector-wide weakness. The China underweight was the sole meaningful contributor. US Tech overweight at +8% vs BM is within mandate but approaching the +10% limit.

### Recommended Actions
1. Monitor US Tech overweight — trim if sector momentum turns negative to stay within mandate headroom
2. Review Nvidia and ASML sizing ahead of next earnings cycle — both detracted materially

### Open Questions for IC / PM
- Is the China underweight a deliberate long-term view or tactical? If tactical, what's the reversal trigger?
```

### Example 2 — Multi-asset mandate

INPUT:
"Our balanced fund has 65% equities, 30% bonds, 5% cash. Target is 60/35/5. We have a mandate constraint: equities can't exceed 70%. YTD we're up 4.1% vs the 60/40 benchmark at 3.8%."

OUTPUT:
```
## Portfolio Review: Balanced Fund — YTD

### Performance Summary
| Metric | Portfolio | Benchmark (60/40) | +/- |
|--------|-----------|-------------------|-----|
| Return (YTD) | +4.1% | +3.8% | +30 bps |

### Positioning vs Target
| Asset Class | Portfolio | Target | +/- | Status |
|-------------|-----------|--------|-----|--------|
| Equities | 65% | 60% | +5% | OK |
| Bonds | 30% | 35% | -5% | OK |
| Cash | 5% | 5% | 0% | OK |

### Mandate Checks
| Check | Limit | Current | Status |
|-------|-------|---------|--------|
| Max equity allocation | 70% | 65% | OK — 5% headroom |

### Summary
Portfolio is +30 bps ahead of the 60/40 benchmark YTD, with equity overweight driving outperformance in a risk-on environment. Allocation is within mandate with 5% headroom on the equity ceiling.

### Recommended Actions
1. No immediate action required — allocation is within mandate and outperforming
2. Monitor equity drift — if equities rally further, approaching 70% ceiling warrants a trim

### Open Questions for IC / PM
- None
```

## Review Rules (Secondary Reference)

| If the user provides... | Do this |
|------------------------|---------|
| Holdings CSV | Extract weights, calculate sector totals, flag missing prices |
| Performance numbers only | Build performance table, ask for attribution data if not given |
| "We're up X vs Y benchmark" | Produce summary + ask for top contributors/detractors |
| No benchmark specified | Ask — or note "benchmark not provided, absolute return only" |
| Mandate document reference | Extract limits and run all checks before the summary |
