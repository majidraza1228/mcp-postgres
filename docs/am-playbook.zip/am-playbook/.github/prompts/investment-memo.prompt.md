---
mode: 'agent'
description: 'Use this skill when writing an investment thesis, research note, or buy/hold/sell recommendation on a security, company, or asset. Triggers on ''write an investment memo'', ''write a research note'', ''investment thesis '
---

# /investment-memo

Load and follow the canonical skill definition at:
**am-skills/investment-memo/SKILL.md**

---

---
name: investment-memo
description: >
  Use this skill when writing an investment thesis, research note, or buy/hold/sell
  recommendation on a security, company, or asset. Triggers on 'write an investment
  memo', 'write a research note', 'investment thesis for', 'make the case for buying',
  'write up a sell recommendation', 'document our view on', 'IC note for', 'write
  a credit memo', 'investment case for', or 'help me structure my thinking on this
  name'. Covers equities, credit, rates, FX, and real assets. Do NOT use for
  reviewing the whole portfolio — use /skills/portfolio-review instead. Do NOT use
  for client-facing commentary — use /skills/client-reporting instead.
version: "1.0"
updated: "2026-06-13"
---

# Investment Memo Skill

## Safety — Read First

- NEVER fabricate metrics, prices, or financial data — use only what the user provides
- NEVER present a recommendation without stating key risks
- If the user has not provided valuation data, build the structure and flag where numbers are needed
- Mark forward-looking statements clearly: "we believe", "we expect", "in our view"

## The Memo Process

```
1. IDENTIFY   — Security, asset class, coverage universe, analyst
2. THESIS     — What you think, why market is mispricing it, what the catalyst is
3. VALUATION  — Key metrics vs peers and historical range
4. RISKS      — Main risks ranked by likelihood and impact
5. CATALYSTS  — What changes the price in your time horizon
6. SIZING     — Position sizing recommendation and limit check
```

## Output Template

```
## Investment Memo: {Company / Security / Ticker} — {Date}

**Asset class:** {Equity / IG Credit / HY Credit / Rates / FX / Real Asset}
**Analyst:** {Name}
**Coverage:** {Fund(s) this is relevant to}

---

### Recommendation
**{BUY / ADD / HOLD / REDUCE / SELL}**
Target: {price / yield / spread}
Upside / downside to target: {X}%
Conviction: {HIGH / MEDIUM / LOW}
Time horizon: {3m / 6m / 12m / multi-year}

---

### Thesis (3 bullets)
1. {What you believe that the consensus doesn't}
2. {Key driver — what gets you to target}
3. {Catalyst — specific event or inflection that unlocks value}

### Valuation
| Metric | Current | 1yr Avg | 3yr Avg | Peer Median | Note |
|--------|---------|---------|---------|-------------|------|
| {e.g. P/E, EV/EBITDA, YTM, Spread} | | | | | |

### Risk Factors
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| {risk} | H / M / L | H / M / L | {how you'd respond} |

### Catalysts & Timeline
| Catalyst | Expected Date | Expected Impact |
|----------|--------------|-----------------|
| {e.g. Earnings, Fed decision, M&A} | {date} | {directional} |

### Position Sizing
Current weight: {X}% | Recommended weight: {Y}%
Change: {+/-Z}%
Mandate check: {Within limit / Flag}

### Appendix / Data Sources
- {Bloomberg, company filings, model, etc.}

---
*This memo represents an internal investment view and is not investment advice.*
```

## Worked Examples

### Example 1 — Equity buy note

INPUT:
"Write an investment memo for LVMH. We think luxury demand is recovering faster than consensus expects after the China reopening slowdown. Stock is at €680, we think it's worth €800 in 12 months. Main risks are China slowdown dragging on, and FX headwinds from a strong euro. Q2 earnings in July are the key catalyst."

OUTPUT:
```
## Investment Memo: LVMH (MC FP) — 13 Jun 2026

**Asset class:** European Equity
**Analyst:** —
**Coverage:** Global Equity Fund, European Equity Fund

---

### Recommendation
**BUY**
Target: €800 | Current: €680
Upside to target: +18%
Conviction: MEDIUM
Time horizon: 12 months

---

### Thesis
1. Luxury demand is recovering faster than sell-side consensus expects — we believe Q2 organic growth will surprise to the upside as Chinese consumer confidence normalises post-2025 slowdown
2. LVMH's brand pricing power insulates margins even in a softening macro — historically maintains EBIT margins >20% through cycles
3. Q2 earnings (July 2026) are the catalyst: a beat on Asia-Pacific revenues will re-rate the stock toward its 3yr average P/E of 25x vs current 20x

### Valuation
| Metric | Current | 1yr Avg | 3yr Avg | Peer Median | Note |
|--------|---------|---------|---------|-------------|------|
| P/E (NTM) | 20x | 22x | 25x | 23x | Discount to history and peers |
| EV/EBITDA | 12x | 14x | 16x | 14x | De-rated on China concerns |
| FCF Yield | 4.5% | 3.8% | 3.2% | 3.5% | Attractive vs own history |

### Risk Factors
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| China demand stays weak through H2 | M | H | Size conservatively; set stop at €620 |
| EUR/USD strengthens further (FX headwind) | M | M | Monitor FX hedge ratio in Q2 results |
| US luxury spending softens (tariffs) | L | M | US is ~25% of revenues — manageable |

### Catalysts & Timeline
| Catalyst | Expected Date | Expected Impact |
|----------|--------------|-----------------|
| Q2 Earnings | July 2026 | Asia-Pac organic growth: key swing factor |
| China macro data (retail sales) | Monthly | Leading indicator for sentiment |
| EUR strength reversal | Uncertain | Positive for USD-reported earnings |

### Position Sizing
Current weight: 2.5% | Recommended weight: 3.5%
Change: +1.0%
Mandate check: Within single-name limit (max 5%)

### Appendix / Data Sources
- Bloomberg consensus as of 13 Jun 2026
- LVMH FY2025 Annual Report
- Internal China consumer confidence model
```

### Example 2 — Credit sell note

INPUT:
"We hold Baa3/BBB- rated bonds from a US regional bank. Spreads have tightened to 120bps over treasuries. We think the credit is deteriorating — CRE exposure is high and deposit flows are shaky. We'd sell and reinvest in higher-quality IG."

OUTPUT:
```
## Investment Memo: {US Regional Bank} — 13 Jun 2026

**Asset class:** US IG Credit
**Analyst:** —
**Coverage:** Fixed Income Fund, Balanced Fund

---

### Recommendation
**SELL**
Current spread: 120bps | Fair value estimate: 180-200bps
Downside to fair value: -60 to -80bps (price negative)
Conviction: MEDIUM-HIGH
Time horizon: 3-6 months

---

### Thesis
1. CRE loan book deterioration is not fully priced — elevated office and retail exposure in markets with rising vacancy rates will drive credit losses above consensus in H2 2026
2. Deposit outflows remain a tail risk — funding base is not stabilised, creating liquidity vulnerability if sentiment turns
3. At 120bps, the bond offers inadequate compensation for idiosyncratic risk — higher-quality IG peers trade at 80bps with stronger balance sheets

### Risk Factors
| Risk | Likelihood | Impact | Mitigation |
|------|------------|--------|------------|
| Spreads tighten further before widening | M | M | Scale out in tranches rather than all at once |
| Credit actually stabilises faster than expected | L | M | Review after Q2 earnings; set re-entry at 160bps |

### Position Sizing
Current weight: 1.8% | Recommended weight: 0%
Change: -1.8% (full exit)
Reinvestment: Higher-quality IG financials at 80-90bps

### Appendix / Data Sources
- Bloomberg credit monitor
- FDIC call reports
- Internal CRE stress model
```

## Memo Quality Rules (Secondary Reference)

**Thesis quality check:**
- Each bullet answers a different question: "what do we think?", "why does it get there?", "what changes it?"
- Avoid generic statements: "strong management team", "good brand" — make them specific and falsifiable

**Risk quality check:**
- Every risk should have a likelihood AND an impact — both together determine priority
- Every HIGH/HIGH risk must have a mitigation — otherwise it's a reason not to own the position

**When to stop and ask:**
- No valuation data → ask for or flag where numbers are missing before completing the memo
- No catalysts identified → flag — a thesis without a catalyst is just a view
- No position sizing context → ask for current weight and mandate limits
