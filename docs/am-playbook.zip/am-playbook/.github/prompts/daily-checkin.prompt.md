---
mode: 'agent'
description: 'Use this skill when a team member wants to submit their daily check-in or status update to the shared team log. Triggers on ''check in'', ''add my update'', ''log what I did today'', ''post my check-in'', ''write my dail'
---

# /daily-checkin

Load and follow the canonical skill definition at:
**pm-skills/daily-checkin/SKILL.md**

---

---
name: daily-checkin
description: >
  Use this skill when a team member wants to submit their daily check-in or
  status update to the shared team log. Triggers on 'check in', 'add my update',
  'log what I did today', 'post my check-in', 'write my daily update', 'submit
  my standup', or 'add to the team log'. Reads the current sprint board and
  prior check-in automatically, then appends a structured entry to TEAM.md.
  Do NOT use for full project planning — use /skills/sprint-planning instead.
  Do NOT use for reading the team summary — use /skills/team-digest instead.
version: "1.0"
updated: "2026-06-13"
---

# Daily Check-in Skill (AM Edition)

## Safety — Read First

- NEVER include client names, account numbers, fund PII, or confidential trade information in TEAM.md
- NEVER fabricate work — only include what actually happened
- If a blocker involves a compliance or regulatory issue, write "COMPLIANCE BLOCKER — discuss offline" rather than details in the shared file

## Step 1: Gather context automatically

Read these sources before asking anything:

| Source | Path | What to extract |
|--------|------|----------------|
| Sprint board | `SPRINT.md` (root or `docs/SPRINT.md`) | Tasks assigned to this user and their status |
| Team log | `TEAM.md` (root or `docs/TEAM.md`) | Last entry by this user — to avoid duplicating |

## Step 2: Ask one question

If SPRINT.md gives enough context, ask only:

> "Anything blocked, delayed, or worth flagging to the team?"

If context is thin (no sprint tasks, no recent entry), ask:

> "What did you work on today, what's next, and is anything blocked?"

One message only — do not ask multiple separate questions.

## Step 3: Append to TEAM.md

Format the entry exactly as below, then append it to `TEAM.md`. Create the file if it doesn't exist.

After appending, confirm: "Check-in added to TEAM.md."

## Output Template (what gets appended)

```markdown
---

## {YYYY-MM-DD} — @{name}

**Done**
- {specific thing completed — not "worked on X" but "finished X" or "delivered Y to Z"}

**Today**
- {specific next task or action}

**Blocked / Flagged**
- {blocker — who needs to act, or deadline risk — or "None"}
```

## Worked Example

INPUT: User runs `/daily-checkin` — no extra text.

CONTEXT GATHERED from SPRINT.md:
```
[ ] Portfolio review deck for IC — @syed — due Thu (task #3)
[x] Q2 client letter draft — @syed (task #1)
[ ] Risk attribution run for EM fund — @syed (task #5)
```

USER REPLY: "The IC deck is blocked — waiting on final performance numbers from ops."

OUTPUT appended to TEAM.md:
```
---

## 2026-06-13 — @syed

**Done**
- Completed Q2 client letter draft — sent to compliance for review (sprint task #1 ✓)

**Today**
- Run risk attribution for EM fund (sprint task #5)
- Continue IC deck structure — writing narrative sections while performance numbers are pending

**Blocked / Flagged**
- IC portfolio review deck (task #3) — waiting on final Q2 performance numbers from ops team. Due Thursday — flagging now as timeline is tight.
```
