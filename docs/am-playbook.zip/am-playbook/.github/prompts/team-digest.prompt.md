---
mode: 'agent'
description: 'Use this skill to generate a team summary from all daily check-ins. Reads TEAM.md and SPRINT.md, then produces a digest showing what the team did, what''s next, all active blockers, and sprint velocity. Triggers on ''tea'
---

# /team-digest

Load and follow the canonical skill definition at:
**pm-skills/team-digest/SKILL.md**

---

---
name: team-digest
description: >
  Use this skill to generate a team summary from all daily check-ins. Reads
  TEAM.md and SPRINT.md, then produces a digest showing what the team did,
  what's next, all active blockers, and sprint velocity. Triggers on 'team
  digest', 'team summary', 'what is the team working on', 'summarise the
  team log', 'show me the team status', 'get the team update', 'what blockers
  do we have', 'sprint progress summary', or 'morning team brief'. Do NOT use
  for individual check-ins — use /skills/daily-checkin instead.
version: "1.0"
updated: "2026-06-13"
---

# Team Digest Skill (AM Edition)

## Safety — Read First

- NEVER include information not present in TEAM.md or SPRINT.md — do not invent or infer status
- If TEAM.md has not been updated in more than 2 days, flag this in the digest
- Escalate blockers that have been open for more than 2 days as requiring action

## Step 1: Read both files

| Source | Path | What to extract |
|--------|------|----------------|
| Sprint board | `SPRINT.md` | Task list, owners, statuses, blockers table |
| Team log | `TEAM.md` | All entries since last digest or last 5 business days |

## Step 2: Produce the digest

Do not ask questions — read the files and produce the output directly.

## Output Template

```
## Team Digest — {YYYY-MM-DD}

### Sprint Status
**{Sprint Name}** — {N} days remaining
Goal: {sprint goal from SPRINT.md}

| Status | Count |
|--------|-------|
| Done | {N} |
| In Progress | {N} |
| Not Started | {N} |
| Blocked | {N} |

### What the Team Did (last 24-48h)
{@name} — {1-line summary of their Done items}
{@name} — {1-line summary}

### What's Up Next
{@name} — {Today items from most recent check-in}
{@name} — {Today items}

### Active Blockers
| Blocker | Who's blocked | Who needs to act | Days open |
|---------|--------------|-----------------|-----------|
| {description} | @{name} | @{owner/team} | {N} |

{If no blockers: "No active blockers."}

### Sprint Velocity
Tasks completed this sprint: {N} / {total}
{If behind pace: "⚠️ Behind pace — {N} tasks remain with {N} days left."}
{If on track: "On track."}

### Flagged / Needs Attention
- {Any item open >2 days, late check-ins, approaching deadlines}
```

## Worked Example

TEAM.md contents (last 2 days):
```
## 2026-06-12 — @syed
Done: Completed Q2 client letter draft
Today: Run EM risk attribution, work on IC deck
Blocked: IC deck waiting on ops performance numbers

## 2026-06-12 — @aisha
Done: Updated compliance checklist for new mandate
Today: External manager DD — investment process section
Blocked: None

## 2026-06-13 — @syed
Done: EM risk attribution run complete — sent to risk team
Today: IC deck narrative sections, follow up with ops
Blocked: IC deck (task #3) — ops performance numbers still outstanding
```

SPRINT.md: 10 tasks total, 3 done, 1 blocked, 6 in progress.

OUTPUT:
```
## Team Digest — 2026-06-13

### Sprint Status
**Q2 IC Prep Sprint** — 4 days remaining
Goal: IC deck, Q2 client letters, and EM risk review complete before quarterly IC.

| Status | Count |
|--------|-------|
| Done | 3 |
| In Progress | 6 |
| Not Started | 0 |
| Blocked | 1 |

### What the Team Did (last 24-48h)
@syed — Completed Q2 client letter draft (sent to compliance) + EM risk attribution run
@aisha — Updated compliance checklist for new mandate

### What's Up Next
@syed — IC deck narrative sections + chasing ops for performance numbers
@aisha — External manager DD: investment process section

### Active Blockers
| Blocker | Who's blocked | Who needs to act | Days open |
|---------|--------------|-----------------|-----------|
| Final Q2 performance numbers not received | @syed (IC deck, task #3) | Ops team | 2 days |

### Sprint Velocity
Tasks completed this sprint: 3 / 10
⚠️ Behind pace — 7 tasks remain with 4 days left. IC deck blocker is on the critical path.

### Flagged / Needs Attention
- Ops performance numbers have been outstanding for 2 days — IC deck is blocked and due Thursday. Escalate to ops lead today.
```
