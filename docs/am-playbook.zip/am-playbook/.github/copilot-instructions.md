# GitHub Copilot — Repository Instructions

These instructions tell GitHub Copilot Chat how to behave in this repository.
For full context, see [AGENTS.md](../AGENTS.md) at the repo root.

---

## What this repo is

This is the **Asset Management Agentic Playbook** — a library of structured Markdown *skills* (under `am-skills/`, `dev-basics/`, `pm-skills/`) used by asset-management professionals.

**Asset Management (AM)** = institutional investing (funds, mandates, IC, benchmarks, structured products like CLOs).

Every skill lives at `<layer>/<skill-name>/SKILL.md` with YAML frontmatter (`name`, `description`, `version`).

---

## How Copilot should behave here

### Slash-command skill invocation
Each skill is mirrored as a Copilot prompt file at `.github/prompts/<skill-name>.prompt.md`. The user can invoke a skill in chat with `/<skill-name>` (e.g. `/portfolio-review`, `/clo-deal-review`).

When invoked, the prompt file instructs Copilot to load and follow the corresponding `SKILL.md`.

### Free-form requests
When the user describes a task (without `/slash`) and it matches a skill's `description` triggers, suggest the relevant skill and follow its template.

Examples:
- User: *"Review the Global Equity fund for May."* → use `am-skills/portfolio-review/SKILL.md`.
- User: *"Write up an IC memo on LVMH."* → use `am-skills/investment-memo/SKILL.md`.
- User: *"Write a Q1 client letter."* → use `am-skills/client-reporting/SKILL.md`.
- User: *"Check our TE."* → use `am-skills/risk-attribution/SKILL.md`.
- User: *"Review Beacon CLO VII."* → use `am-skills/clo-deal-review/SKILL.md`.
- User: *"Is this trade compliant with the IPS?"* → use `am-skills/compliance-check/SKILL.md`.
- User: *"Break down our active return by sector."* → use `am-skills/performance-attribution/SKILL.md`.

### Hard rules (apply to EVERY response in this repo)

1. **Never fabricate financial data** — performance numbers, balances, holdings, prices, CLO test cushions, ratings. Use only what the user provides.
2. **Never give formal investment advice.** Always end regulated outputs with an appropriate reviewer reminder (firm compliance / IC).
3. **Always follow a skill's Output Template strictly.** Format consistency is the point.
4. **Always honour a skill's Safety block.** Don't skip safety items even if asked.
5. **Flag stale or missing inputs** rather than guessing.
6. **No PII in outputs** beyond what the user provided.

### Code edits
When editing a `SKILL.md`:
- Preserve the YAML frontmatter structure (`name`, `description ≥ 150 chars`, `version`, `updated`).
- Don't break the canonical sections: `Safety — Read First`, `Process`, `Output Template`, `Worked Example(s)`.
- After editing, recommend running `./scripts/install-skills.sh --copilot` to regenerate the matching prompt file.

When editing `docs/index.html`:
- It is a single self-contained file (vanilla HTML/CSS/JS, no build step).
- The `SKILLS` array in the inline `<script>` is the source of truth for the skill browser. Keep it in sync with the actual skill files.

---

## Cross-platform compatibility

The same `SKILL.md` files are also consumed by Claude Code and OpenAI Codex (via `AGENTS.md`). If you change a skill here, you change it for all three. That's by design.
