# Skill Workflows

> How to chain skills in this playbook into end-to-end AM tasks.
> Each skill is self-contained (see `AGENTS.md`), but most real work is a **pipeline**:
> the Output Template of one skill becomes the input to the next.
>
> Invoke with `/<skill-name>` in **GitHub Copilot Chat**, or describe the task in
> plain English to **Codex** (it reads `AGENTS.md` and routes automatically).

---

## 1. Monthly Portfolio Cycle

**Use when:** it's month-end / quarter-end and you need to go from raw numbers to a client-ready letter.

```
sql  →  portfolio-review  →  risk-attribution  →  compliance-check  →  client-reporting
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `sql` | Pulls holdings, weights, and returns from the portfolio/trade database |
| 2 | `portfolio-review` | Performance vs. benchmark, top contributors/detractors, positioning |
| 3 | `risk-attribution` | Factor decomposition, concentration, risk budget status |
| 4 | `compliance-check` | Pass/fail scan against IPS limits, restricted list, exclusions |
| 5 | `client-reporting` | Client letter / factsheet commentary, using steps 2-4 as source material |

**Why chain this way:** `client-reporting` should never invent performance or risk numbers —
feed it the finished tables from `portfolio-review` / `risk-attribution` / `compliance-check`
so the letter is fully traceable back to a reviewed source.

---

## 2. Idea → IC → Execution

**Use when:** a PM/analyst has a new idea and it needs to move from thesis to a tracked action.

```
investment-memo  →  ticket-writer  (→ sprint-planning if it's a multi-week initiative)
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `investment-memo` | Buy/hold/sell thesis, valuation, risks, catalysts, sizing |
| 2 | `ticket-writer` | Concrete follow-up tasks (e.g. "size position", "add to watchlist", "schedule earnings review") |
| 3 (optional) | `sprint-planning` | If the idea triggers a larger project (e.g. new strategy build-out), break it into a tracked plan |

---

## 3. CLO Surveillance Cycle

**Use when:** running monthly/quarterly CLO surveillance across a book of deals.

```
clo-deal-review  →  compliance-check  →  client-reporting
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `clo-deal-review` | Capital stack, OC/IC test cushions, collateral pool health, manager RV view |
| 2 | `compliance-check` | Confirms deal/tranche still meets mandate concentration and rating-bucket limits |
| 3 | `client-reporting` | Investor-facing surveillance update, sourced from steps 1-2 |

---

## 4. Risk & Compliance Loop

**Use when:** a risk or compliance flag needs to turn into remediation work, not just a report.

```
risk-attribution  →  compliance-check  →  ticket-writer
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `risk-attribution` | Identifies breach/watch items and risk drivers |
| 2 | `compliance-check` | Confirms breach status against the formal IPS/mandate rule set (pass/fail, not just "watch") |
| 3 | `ticket-writer` | One ticket per remediation action, with owner and deadline |

---

## 5. Quantitative Attribution Pipeline

**Use when:** you need a formal Brinson-style allocation/selection/interaction breakdown, not just position-level contributors/detractors.

```
sql  →  performance-attribution  →  portfolio-review
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `sql` | Sector/asset-class weights and returns, portfolio vs. benchmark |
| 2 | `performance-attribution` | Allocation, selection, and interaction effects by sector |
| 3 | `portfolio-review` | Folds the sector-level Brinson results into the full review alongside position-level detail |

**Note:** `performance-attribution` is the sector-level *methodology* skill (Brinson-Fachler);
`portfolio-review` still owns position-level "top contributors/detractors." Use both together
for a complete attribution picture.

---

## 6. Team Ops Loop

**Use when:** running day-to-day team coordination alongside AM work.

```
daily-checkin  (per person, daily)  →  team-digest  (weekly)  →  sprint-planning  (as needed)
```

| Step | Skill | Produces |
|------|-------|----------|
| 1 | `daily-checkin` | Each team member logs Done/Today/Blocked to `TEAM.md` |
| 2 | `team-digest` | Rolls up all check-ins into a summary with blockers and velocity |
| 3 | `sprint-planning` | Re-scopes `SPRINT.md` when the digest surfaces slippage or new work |

---

## Adding a new workflow

When a new skill is added (see `AGENTS.md` → "Conventions for contributors"), check whether
it fits into an existing chain above or forms a new one, and update this file — workflows
drift out of date faster than individual skills.
