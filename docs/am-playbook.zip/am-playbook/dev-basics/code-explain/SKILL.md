---
name: code-explain
description: >
  Use this skill when an AM professional needs to understand code, a script, a
  formula, or a query they didn't write or can't follow. Triggers on 'explain
  this code', 'what does this script do', 'walk me through this', 'explain this
  Python script', 'what does this SQL query do', 'explain this Excel formula',
  'what is this VBA macro doing', 'explain this Bloomberg function', 'I don't
  understand this', or 'what does this return'. Explains in plain language for
  a finance professional, not a software engineer. Do NOT use for fixing broken
  code — describe the problem and ask for debugging help instead. Do NOT use
  for writing new code — ask directly for what you need built.
version: "1.0"
updated: "2026-06-13"
---

# Code Explain Skill (AM Edition)

## Safety — Read First

- If the code contains API keys, passwords, or client data — flag it immediately before explaining anything
- NEVER execute code to demonstrate behavior — explain it statically from reading it
- Frame explanations for a finance professional, not a software engineer: use financial analogies where they help

## Output Template

Adjust depth to the question. Default to Standard.

```
## What this code does
{1-2 sentences: plain English purpose. If it's financial, name what financial task it performs.}

## How it works
{Step-by-step walkthrough. Number each step. Reference line numbers if code was shared.
Use financial analogies: "this is like a VLOOKUP", "this filters the portfolio like a screen".}

## What it produces
Input:  {example or description of what goes in}
Output: {what comes out — value, file, table, etc.}

## Things to watch out for
{Any gotchas, assumptions the code makes, data format requirements, edge cases that could break it.}
```

## Worked Examples

### Example 1 — Python portfolio script

INPUT:
```python
import pandas as pd

df = pd.read_csv("holdings.csv")
df["weight"] = df["market_value"] / df["market_value"].sum()
top10 = df.nlargest(10, "weight")[["ticker", "weight"]]
print(top10)
```

OUTPUT:
```
## What this code does
Reads a portfolio holdings file and calculates each position's weight, then prints the top 10 positions by weight.

## How it works
1. Line 3: Reads a CSV file called "holdings.csv" into a table (like opening an Excel spreadsheet)
2. Line 4: Creates a new column called "weight" — divides each position's market value by the total portfolio market value. Same logic as calculating a portfolio weight in Excel: =B2/SUM($B$2:$B$100)
3. Line 5: Selects the 10 rows with the largest weights, and keeps only the ticker and weight columns
4. Line 6: Prints the result to the screen

## What it produces
Input:  A CSV file with at least two columns: "ticker" and "market_value"
Output: A table of the 10 largest positions with their portfolio weights (as decimals, e.g. 0.045 = 4.5%)

## Things to watch out for
- The CSV file must be in the same folder as the script, and must have columns named exactly "ticker" and "market_value" (case-sensitive)
- If any market value is missing (blank), the total will be understated and weights will be wrong
- Weights are shown as decimals — multiply by 100 to get percentages
```

### Example 2 — SQL query on trade data

INPUT:
```sql
SELECT ticker, SUM(quantity * price) AS total_value
FROM trades
WHERE trade_date >= '2026-01-01'
  AND direction = 'BUY'
GROUP BY ticker
ORDER BY total_value DESC
LIMIT 20;
```

OUTPUT:
```
## What this code does
Finds the 20 securities with the highest total buy value in 2026, year to date.

## How it works
1. SELECT ticker, SUM(quantity * price) — for each security, calculate the total money spent on buys (quantity × price per trade, summed across all buy trades)
2. FROM trades — looks at the trades table
3. WHERE trade_date >= '2026-01-01' — filters to only trades from 1 Jan 2026 onwards
4. AND direction = 'BUY' — only buy trades (excludes sells)
5. GROUP BY ticker — groups all buy trades for the same security together before summing
6. ORDER BY total_value DESC — sorts largest to smallest by total spend
7. LIMIT 20 — returns only the top 20

## What it produces
Input:  A trades table with columns: ticker, quantity, price, trade_date, direction
Output: A list of up to 20 tickers with their total buy spend in 2026, largest first

## Things to watch out for
- "Total value" here is total cash deployed, not current market value — a position bought for £5m might be worth more or less now
- If the same ticker has both buys and sells in 2026, sells are excluded — this shows gross purchases only
- The query uses a text date format ('2026-01-01') — confirm your database stores dates in the same format or the filter may not work
```

### Example 3 — Excel formula

INPUT:
```
=SUMPRODUCT((B2:B50="Financials")*(C2:C50))
```

OUTPUT:
```
## What this code does
Sums the values in column C only for rows where column B says "Financials".
This is the Excel equivalent of a filtered SUM — useful for sector weight calculations.

## How it works
1. (B2:B50="Financials") — checks each cell in column B against the word "Financials". Returns TRUE (=1) or FALSE (=0) for each row.
2. (C2:C50) — the values you want to sum (e.g. portfolio weights or market values)
3. SUMPRODUCT multiplies the two arrays together element by element, then sums them.
   Result: rows where B = "Financials" are multiplied by 1 (included), all others by 0 (excluded).

## What it produces
Input:  Column B = sector names, Column C = portfolio weights or values
Output: A single number — the total weight (or value) of all Financials positions

## Things to watch out for
- The text match is exact and case-sensitive — "financials" (lowercase) won't match "Financials"
- If your sector labels have trailing spaces (common when pasting from Bloomberg), the match will fail — use TRIM() to clean: =(TRIM(B2:B50)="Financials")
- Adjust the range (B2:B50) to match your actual data size
```

## Explanation Depth Guide

| User says | Depth |
|-----------|-------|
| "what does this do" | One-sentence summary only |
| "explain this" | Standard template |
| "walk me through line by line" | Full step-by-step with line references |
| "explain like I've never coded" | Add analogies to Excel/Bloomberg equivalents |
| "why is it written this way" | Focus on design choices and alternatives |
