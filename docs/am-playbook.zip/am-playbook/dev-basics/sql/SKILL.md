---
name: sql
description: >
  Use this skill when an AM professional needs to write, read, or fix a SQL
  query against portfolio, trade, performance, NAV, or market data. Triggers
  on 'write a SQL query', 'query the database', 'get me the data for', 'how
  do I pull this from the database', 'SQL for portfolio holdings', 'query to
  find all trades', 'how do I get performance data out', 'SQL to calculate
  weights', 'pull all positions where', or 'write a query to show me'. Designed
  for non-engineers querying common AM data structures. Do NOT use for
  understanding existing code — use /skills/code-explain instead. Do NOT use
  for schema design — ask for that separately.
version: "1.0"
updated: "2026-06-13"
---

# SQL Skill (AM Edition)

## Safety — Read First

- NEVER write a DELETE or UPDATE query without an explicit WHERE clause — always confirm scope before execution
- Add a `LIMIT 100` to any SELECT query when the user is exploring data for the first time — prevents returning millions of rows
- Flag any query that touches client data or PII and remind the user to check data access permissions
- For destructive queries (DELETE, UPDATE, DROP), show the SELECT equivalent first and ask for confirmation

## Common AM Tables Reference

| Table | Typical columns | Used for |
|-------|----------------|---------|
| `positions` / `holdings` | account_id, ticker, quantity, market_value, as_of_date | Current portfolio weights and exposure |
| `trades` | trade_id, ticker, direction, quantity, price, trade_date, account_id | Transaction history, turnover analysis |
| `performance` | account_id, date, daily_return, nav | Return calculations, drawdown |
| `benchmarks` | benchmark_id, date, ticker, weight | Index weights for active/passive analysis |
| `nav` | account_id, date, nav_value | Fund-level NAV and AUM |
| `clients` / `accounts` | account_id, client_name, mandate_type | Client and mandate metadata |
| `securities` | ticker, name, sector, geography, asset_class | Security master / reference data |

## Output Template

```
## Query: {what this query does in plain English}

```sql
{query here}
```

**Returns:** {description of what each column in the output represents}

**Assumptions:**
- {table name assumed / column name assumed}
- {date format, currency, etc.}

**Before running:** {anything to check or confirm first — especially for write queries}
```

## Worked Examples

### Example 1 — Portfolio weights by sector

REQUEST: "Give me each sector's total weight in the portfolio as of today."

OUTPUT:
```
## Query: Sector weights in portfolio as of today

```sql
SELECT
    s.sector,
    SUM(p.market_value) AS total_market_value,
    SUM(p.market_value) / SUM(SUM(p.market_value)) OVER () AS sector_weight
FROM positions p
JOIN securities s ON p.ticker = s.ticker
WHERE p.as_of_date = CURRENT_DATE
GROUP BY s.sector
ORDER BY sector_weight DESC;
```

**Returns:**
- `sector` — sector name (e.g. "Technology", "Financials")
- `total_market_value` — sum of market value for all positions in that sector
- `sector_weight` — that sector's weight as a decimal (multiply by 100 for %)

**Assumptions:**
- Table `positions` has columns: ticker, market_value, as_of_date
- Table `securities` has columns: ticker, sector
- `CURRENT_DATE` uses today's date — if data isn't refreshed daily, replace with the last available date

**Before running:** Check that `as_of_date` in your positions table matches the format used above (DATE type vs text string).
```

### Example 2 — Top 10 positions by weight

REQUEST: "Show me the top 10 holdings by portfolio weight."

OUTPUT:
```
## Query: Top 10 positions by weight

```sql
SELECT
    p.ticker,
    s.name,
    s.sector,
    p.market_value,
    p.market_value / SUM(p.market_value) OVER () AS weight
FROM positions p
JOIN securities s ON p.ticker = s.ticker
WHERE p.as_of_date = CURRENT_DATE
ORDER BY weight DESC
LIMIT 10;
```

**Returns:**
- `ticker` — security identifier
- `name` — full company name
- `sector` — sector classification
- `market_value` — market value in base currency
- `weight` — position weight as a decimal (e.g. 0.042 = 4.2%)

**Assumptions:**
- Positions and securities tables joined on ticker
- `as_of_date = CURRENT_DATE` — replace with a specific date if needed
```

### Example 3 — Monthly fund return calculation

REQUEST: "Calculate the monthly return for each fund in 2026."

OUTPUT:
```
## Query: Monthly returns by fund, 2026

```sql
SELECT
    account_id,
    DATE_TRUNC('month', date) AS month,
    (LAST_VALUE(nav_value) OVER w / FIRST_VALUE(nav_value) OVER w) - 1 AS monthly_return
FROM nav
WHERE date BETWEEN '2026-01-01' AND '2026-12-31'
WINDOW w AS (
    PARTITION BY account_id, DATE_TRUNC('month', date)
    ORDER BY date
    ROWS BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING
)
GROUP BY account_id, month, monthly_return
ORDER BY account_id, month;
```

**Returns:**
- `account_id` — fund identifier
- `month` — first day of each month
- `monthly_return` — that month's return as a decimal (multiply by 100 for %)

**Assumptions:**
- `nav` table has: account_id, date, nav_value
- `DATE_TRUNC` is PostgreSQL syntax — for SQLite use `strftime('%Y-%m', date)`; for SQL Server use `DATETRUNC`

**Before running:** Confirm your database type (PostgreSQL / SQLite / SQL Server) as date functions differ.
```

### Example 4 — Trades above a threshold this month

REQUEST: "Find all buy trades over £500,000 this month."

OUTPUT:
```
## Query: Buy trades over £500,000 this month

```sql
SELECT
    trade_id,
    ticker,
    quantity,
    price,
    quantity * price AS trade_value,
    trade_date,
    account_id
FROM trades
WHERE direction = 'BUY'
  AND trade_date >= DATE_TRUNC('month', CURRENT_DATE)
  AND quantity * price > 500000
ORDER BY trade_value DESC
LIMIT 100;
```

**Returns:**
- `trade_id` — unique trade identifier
- `ticker` — security traded
- `quantity` and `price` — raw trade data
- `trade_value` — calculated: quantity × price (in base currency)
- `trade_date` — execution date
- `account_id` — which fund/account

**Assumptions:**
- `direction = 'BUY'` — confirm your system uses this exact value (could be 'B', 'Purchase', etc.)
- Trade value = quantity × price assumes price is per unit — confirm if your price field is already a total
```

## SQL Quick Reference for AM Professionals

| If you want to... | SQL pattern |
|-------------------|------------|
| Filter by date | `WHERE date >= '2026-01-01' AND date <= '2026-12-31'` |
| Filter by fund | `WHERE account_id = 'FUND_A'` |
| Sum values by group | `GROUP BY sector` with `SUM(market_value)` |
| Calculate a weight | `market_value / SUM(market_value) OVER ()` |
| Join position to security info | `JOIN securities ON positions.ticker = securities.ticker` |
| Get the most recent data | `WHERE date = (SELECT MAX(date) FROM positions)` |
| Top N results | `ORDER BY value DESC LIMIT 10` |
| Avoid returning too many rows | Add `LIMIT 100` while exploring |

## Before Running Any Query

1. Is this a `SELECT` (read-only) or does it modify data? If it modifies data — confirm scope first
2. Do you have permission to access the tables queried?
3. Does the query touch client data? Check your firm's data access policy
4. Is there a `LIMIT` on exploratory queries to prevent returning millions of rows?
