#!/usr/bin/env bash
# Install / mirror AM-WM Playbook skills across platforms.
#
# Usage:
#   ./scripts/install-skills.sh --claude --global    # ~/.claude/skills/
#   ./scripts/install-skills.sh --claude --local     # ./.claude/skills/
#   ./scripts/install-skills.sh --copilot            # .github/prompts/*.prompt.md
#   ./scripts/install-skills.sh --all                # Copilot prompts + Claude global
#
# Backwards-compatible:
#   ./scripts/install-skills.sh --global    (= --claude --global)
#   ./scripts/install-skills.sh --local     (= --claude --local)

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"

# ─── Skill registry — keep in sync with AGENTS.md ───
SKILLS=(
  "am-skills/portfolio-review"
  "am-skills/investment-memo"
  "am-skills/client-reporting"
  "am-skills/risk-attribution"
  "am-skills/clo-deal-review"
  "am-skills/compliance-check"
  "am-skills/performance-attribution"
  "dev-basics/code-explain"
  "dev-basics/sql"
  "pm-skills/sprint-planning"
  "pm-skills/ticket-writer"
  "pm-skills/daily-checkin"
  "pm-skills/team-digest"
)

usage() {
  cat <<EOF
Usage: $0 <target> [scope]

Targets:
  --claude    Install SKILL.md files for Claude Code (use with --global or --local)
  --copilot   Generate .github/prompts/<name>.prompt.md for GitHub Copilot
  --all       Run --copilot AND --claude --global

Scopes (only with --claude):
  --global    ~/.claude/skills/         (available in all projects)
  --local     ./.claude/skills/         (current project only)

Examples:
  $0 --claude --global
  $0 --copilot
  $0 --all
EOF
  exit 1
}

install_claude() {
  local scope="$1"
  local target
  case "$scope" in
    --global) target="$HOME/.claude/skills" ;;
    --local)  target="$(pwd)/.claude/skills" ;;
    *) echo "Error: --claude requires --global or --local"; usage ;;
  esac

  mkdir -p "$target"
  echo "Installing skills for Claude Code → $target"

  for skill_path in "${SKILLS[@]}"; do
    local skill_name src dest
    skill_name=$(basename "$skill_path")
    src="$REPO_DIR/$skill_path/SKILL.md"
    dest="$target/$skill_name.md"

    if [[ -f "$src" ]]; then
      cp "$src" "$dest"
      echo "  ✓ $skill_name"
    else
      echo "  ✗ $skill_name — not found at $src"
    fi
  done

  echo ""
  echo "Done. Invoke with /<skill-name> in Claude Code."
}

generate_copilot_prompts() {
  local target="$REPO_DIR/.github/prompts"
  mkdir -p "$target"

  echo "Generating Copilot prompt files → $target"

  for skill_path in "${SKILLS[@]}"; do
    local skill_name src dest description
    skill_name=$(basename "$skill_path")
    src="$REPO_DIR/$skill_path/SKILL.md"
    dest="$target/$skill_name.prompt.md"

    if [[ ! -f "$src" ]]; then
      echo "  ✗ $skill_name — source missing at $src"
      continue
    fi

    # Pull the first paragraph of the SKILL.md description for the prompt file front-matter.
    description=$(awk '
      /^description: *>/{flag=1; next}
      flag && /^[a-z_]+: /{flag=0}
      flag && NF{gsub(/^[ \t]+/,""); gsub(/[ \t]+$/,""); printf "%s ", $0}
    ' "$src" | sed 's/  */ /g; s/ *$//')

    {
      printf -- "---\n"
      printf "mode: 'agent'\n"
      printf "description: '%s'\n" "$(echo "$description" | sed "s/'/''/g" | cut -c1-220)"
      printf -- "---\n\n"
      printf "# /%s\n\n" "$skill_name"
      printf "Load and follow the canonical skill definition at:\n"
      printf "**%s**\n\n" "$skill_path/SKILL.md"
      printf -- "---\n\n"
      cat "$src"
    } > "$dest"

    echo "  ✓ $skill_name.prompt.md"
  done

  echo ""
  echo "Done. Invoke with /<skill-name> in GitHub Copilot Chat."
}

# ─── Argument routing ───
if [[ $# -lt 1 ]]; then usage; fi

case "$1" in
  --global|--local)
    # Back-compat: bare scope = Claude install
    install_claude "$1"
    ;;
  --claude)
    install_claude "${2:-}"
    ;;
  --copilot)
    generate_copilot_prompts
    ;;
  --all)
    generate_copilot_prompts
    echo ""
    install_claude "--global"
    ;;
  *)
    usage
    ;;
esac
