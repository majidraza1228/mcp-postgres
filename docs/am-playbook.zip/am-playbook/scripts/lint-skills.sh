#!/usr/bin/env bash
# Validate every SKILL.md against the playbook's structural conventions.
#
# Checks per skill:
#   - Frontmatter has name, description, version, updated
#   - `name:` matches the parent directory name
#   - `description` is a >=150 char block (Claude Code auto-routing needs real length)
#   - Required canonical sections are present: Safety — Read First, a "Process"
#     section, Output Template, Worked Example(s)
#
# Usage:
#   ./scripts/lint-skills.sh              # lint every SKILL.md found under the layer dirs
#   ./scripts/lint-skills.sh path/to/SKILL.md   # lint a single file

set -u

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"

MIN_DESC_LEN=150
FAIL=0

lint_file() {
  local file="$1"
  local dir skill_name errors=0
  dir="$(dirname "$file")"
  skill_name="$(basename "$dir")"

  echo "Checking $file"

  # Frontmatter must exist (--- ... ---)
  if ! awk 'NR==1 && /^---$/{f=1; next} f && /^---$/{exit} f' "$file" | grep -q '.'; then
    echo "  ✗ missing or empty YAML frontmatter"
    errors=$((errors + 1))
  fi

  local fm
  fm=$(awk '/^---$/{c++; next} c==1' "$file")

  # name:
  local name_val
  name_val=$(echo "$fm" | grep -E '^name:' | head -1 | sed 's/^name: *//; s/[[:space:]]*$//')
  if [[ -z "$name_val" ]]; then
    echo "  ✗ missing 'name' field"
    errors=$((errors + 1))
  elif [[ "$name_val" != "$skill_name" ]]; then
    echo "  ✗ name '$name_val' does not match directory '$skill_name'"
    errors=$((errors + 1))
  fi

  # version:
  if ! echo "$fm" | grep -qE '^version:'; then
    echo "  ✗ missing 'version' field"
    errors=$((errors + 1))
  fi

  # updated:
  if ! echo "$fm" | grep -qE '^updated:'; then
    echo "  ✗ missing 'updated' field"
    errors=$((errors + 1))
  fi

  # description: > (folded block) — collect the indented lines that follow
  if ! echo "$fm" | grep -qE '^description:'; then
    echo "  ✗ missing 'description' field"
    errors=$((errors + 1))
  else
    local desc desc_len
    desc=$(echo "$fm" | awk '
      /^description: *>/{flag=1; next}
      flag && /^[a-zA-Z_]+:/{flag=0}
      flag && NF{gsub(/^[ \t]+/,""); gsub(/[ \t]+$/,""); printf "%s ", $0}
    ')
    desc_len=${#desc}
    if [[ "$desc_len" -lt "$MIN_DESC_LEN" ]]; then
      echo "  ✗ description is $desc_len chars — must be >= $MIN_DESC_LEN"
      errors=$((errors + 1))
    fi
  fi

  # Required sections (hard fail — present in every skill today)
  for section in "Safety" "Output Template" "Worked Example"; do
    if ! grep -qE "^##+ .*${section}" "$file"; then
      echo "  ✗ missing required section matching \"$section\""
      errors=$((errors + 1))
    fi
  done

  # Soft-recommended section — several existing skills (simple, non-analytical
  # ones like code-explain, ticket-writer) skip it intentionally, so this is a
  # warning rather than a hard failure.
  if ! grep -qiE '^##+ .*Process' "$file"; then
    echo "  ⚠ no explicit \"Process\" section (e.g. '## The Review Process') — recommended for multi-step analytical skills"
  fi

  if [[ $errors -eq 0 ]]; then
    echo "  ✓ OK"
  else
    FAIL=1
  fi
  echo ""
}

if [[ $# -ge 1 ]]; then
  for f in "$@"; do
    lint_file "$f"
  done
else
  while IFS= read -r -d '' f; do
    lint_file "$f"
  done < <(find "$REPO_DIR/am-skills" "$REPO_DIR/dev-basics" "$REPO_DIR/pm-skills" -name "SKILL.md" -print0 | sort -z)
fi

if [[ $FAIL -ne 0 ]]; then
  echo "Lint FAILED — see ✗ items above."
  exit 1
fi

echo "All skills passed lint."
