# Asset Management Agentic Playbook

Structured AI skills for **Asset Management** — institutional investing, including portfolio review, investment memos, risk attribution, client reporting, and structured-product (CLO) work.

Built so the **same skills run on Claude Code, GitHub Copilot, and OpenAI Codex** — one source of truth, generated adapters for each platform.

---

## What is Asset Management?

**Asset Management (AM)** is the institutional side of investing — running funds, mandates, and pools of capital against benchmarks for institutional clients (pensions, endowments, insurance, sovereign wealth). The work is portfolio management, security analysis, attribution, risk control, structured-product diligence (CLO, ABS, etc.), and reporting to an Investment Committee or board. Language is benchmark-relative: alpha, tracking error, factor exposures, mandate limits.

---

## Who this is for

AM professionals who:
- Manage portfolios or mandates against benchmarks (PMs, analysts)
- Run risk, attribution, or compliance functions
- Write IC notes, factsheets, quarterly letters, client commentary
- Diligence and surveil structured-credit products (CLOs)
- Write Python scripts, SQL queries, or automate reports without a software background
- Coordinate initiatives or run sprints inside an AM team

---

## Skill Layers

### Layer 01 — Asset Management (domain)
Investment and client-facing skills for daily AM work.

| Skill | Use when |
|-------|----------|
| [portfolio-review](am-skills/portfolio-review/SKILL.md) | Review holdings, performance, attribution, mandate compliance |
| [investment-memo](am-skills/investment-memo/SKILL.md) | Write an investment thesis or buy/hold/sell recommendation |
| [client-reporting](am-skills/client-reporting/SKILL.md) | Generate client commentary, quarterly letter, or factsheet text |
| [risk-attribution](am-skills/risk-attribution/SKILL.md) | Break down portfolio risk by factor, sector, and position |
| [clo-deal-review](am-skills/clo-deal-review/SKILL.md) | Review a CLO at issuance, secondary, or surveillance — capital stack, OC/IC tests, collateral pool, manager, RV |
| [compliance-check](am-skills/compliance-check/SKILL.md) | Scan a portfolio or trade against the IPS/mandate rules and restricted/exclusion lists — pass/fail result |
| [performance-attribution](am-skills/performance-attribution/SKILL.md) | Run a Brinson allocation/selection/interaction decomposition of active return |

### Layer 02 — Dev Basics (for the pseudo-developer)
For understanding and writing code without a software engineering background.

| Skill | Use when |
|-------|----------|
| [code-explain](dev-basics/code-explain/SKILL.md) | Need to understand a script, formula, VBA macro, or SQL query |
| [sql](dev-basics/sql/SKILL.md) | Need to query portfolio, trade, performance, or NAV data |

### Layer 03 — Project Management
For running initiatives, coordinating teams, and tracking work.

| Skill | Use when |
|-------|----------|
| [sprint-planning](pm-skills/sprint-planning/SKILL.md) | Break a project or initiative into tracked tasks |
| [ticket-writer](pm-skills/ticket-writer/SKILL.md) | Write a formal task, action item, or issue |
| [daily-checkin](pm-skills/daily-checkin/SKILL.md) | Log your daily update to the shared team board |
| [team-digest](pm-skills/team-digest/SKILL.md) | Generate a team summary from all check-ins |

---

## Platform Compatibility

**One `SKILL.md` per skill — it works everywhere.** Adapters in this repo make each skill discoverable to each platform.

| Platform | How it consumes skills | Setup |
|----------|------------------------|-------|
| **Claude Code** | Native skills format. Frontmatter triggers auto-routing. | `./scripts/install-skills.sh --claude --global` |
| **GitHub Copilot** (VS Code) | Repo-level instructions in `.github/copilot-instructions.md`; one prompt file per skill in `.github/prompts/<name>.prompt.md` (slash-invocable) | `./scripts/install-skills.sh --copilot` (regenerates prompt files) |
| **OpenAI Codex** (CLI / Cloud) | Reads `AGENTS.md` at repo root automatically | No setup — Codex reads `AGENTS.md` on its own |
| **Cursor / Continue / Aider** | Most respect `AGENTS.md`; otherwise paste a SKILL.md into chat | Same as Codex |
| **Anthropic / OpenAI APIs** | Load any `SKILL.md` as a system prompt — they are self-contained | Read the file and pass as `system` |

### How the same skill runs on all three platforms

```
SKILL.md  ← single source of truth
    │
    ├──► Claude Code:  copied into ~/.claude/skills/<name>.md
    │                  (frontmatter triggers auto-routing on plain-English requests)
    │
    ├──► GitHub Copilot:  wrapped into .github/prompts/<name>.prompt.md
    │                     (invoke with /<name> in Copilot Chat;
    │                      .github/copilot-instructions.md handles free-form triggers)
    │
    └──► OpenAI Codex / Cursor / etc:  listed in AGENTS.md
                                       (Codex reads AGENTS.md at session start;
                                        opens the SKILL.md when triggered)
```

### One-time setup commands

```bash
# Install all skills for Claude Code globally (available in every project)
./scripts/install-skills.sh --claude --global

# Install for the current project only
./scripts/install-skills.sh --claude --local

# Regenerate GitHub Copilot prompt files (after editing or adding a skill)
./scripts/install-skills.sh --copilot

# Do everything (Copilot prompts + Claude global install)
./scripts/install-skills.sh --all
```

OpenAI Codex needs no install — it picks up [`AGENTS.md`](AGENTS.md) automatically.

---

## Using a skill

Three platforms, same workflow. Pick the one you already use — the skills behave identically.

### A) GitHub Copilot in VS Code

**Prerequisites**
- VS Code with the GitHub Copilot + Copilot Chat extensions
- This repo open as your workspace (so Copilot reads `.github/copilot-instructions.md` and `.github/prompts/*`)
- Prompt files generated: `./scripts/install-skills.sh --copilot`

**Two invocation modes**

1. **Slash command (explicit)** — in the Copilot Chat panel, type:
   ```
   /portfolio-review
   /clo-deal-review
   /investment-memo
   ```
   Then describe the situation. Copilot loads the matching `.prompt.md`, which embeds the full `SKILL.md`, and follows the Output Template strictly.

2. **Free-form (auto-routed)** — describe the task in plain English:
   ```
   review the European Equity fund for May
   write an IC memo on LVMH
   surveil Beacon CLO VII this quarter
   ```
   `.github/copilot-instructions.md` matches your phrasing to a skill's triggers and applies the right template.

**Agent Mode** (Cmd+Shift+I → switch from "Ask" to "Agent") lets Copilot also edit files and run terminal commands. A request like *"Pull `data/beacon_jun26.csv`, run /clo-deal-review on it, and save the result to `reports/`"* runs end-to-end inside VS Code.

### B) OpenAI Codex (CLI or VS Code extension)

**Prerequisites**
- Codex CLI installed, or the Codex extension in VS Code
- This repo as the working directory (Codex auto-reads `AGENTS.md` at the root)

**Use it**

Just ask in natural language — Codex sees the skill registry in `AGENTS.md` and routes:
```
use the clo-deal-review skill on this trustee report
draft a Q1 client letter using client-reporting
```

No install step. If you add a new skill, just update `AGENTS.md` (and Codex will see it on the next session).

### C) Claude Code (CLI or VS Code extension)

**Prerequisites**
- Claude Code installed (`npm i -g @anthropic-ai/claude-code` or via the VS Code extension)
- Skills installed: `./scripts/install-skills.sh --claude --global`
  - This copies each `SKILL.md` into `~/.claude/skills/` — available in every project, not just this one

**Two invocation modes**

1. **Slash command (explicit)**:
   ```
   /portfolio-review
   /clo-deal-review
   ```

2. **Free-form (auto-routed)** — the `description` frontmatter in each `SKILL.md` is matched against your phrasing. Just describe the task naturally:
   ```
   write me a Q1 client letter for the Global Equity Fund
   ```

### Same skill, three platforms — what happens under the hood

| When you ask… | Copilot reads | Codex reads | Claude reads |
|---|---|---|---|
| `/clo-deal-review` | `.github/prompts/clo-deal-review.prompt.md` (which embeds the SKILL) | `am-skills/clo-deal-review/SKILL.md` (via AGENTS.md pointer) | `~/.claude/skills/clo-deal-review.md` (installed copy) |
| "surveil Beacon CLO VII" | Free-form triggers in `.github/copilot-instructions.md` | Triggers listed in `AGENTS.md` | Triggers in the skill's frontmatter `description` |

Edit the `SKILL.md` once → all three see the new version (after `./scripts/install-skills.sh --all`; Codex needs no regeneration).

---

## Adding a new skill (the full checklist)

Use this whenever you create a new skill so it works across **all three platforms** without manual fixes.

### Step 1 — Create the `SKILL.md`

Pick the right layer folder (`am-skills/`, `dev-basics/`, or `pm-skills/`) and create:

```
<layer>/<skill-name>/SKILL.md
```

Use this canonical structure (copy from any existing skill as a starting template):

```markdown
---
name: skill-name
description: >
  ≥150 characters. Must include realistic trigger phrases the user would
  actually type. Example: "Use this skill when … Triggers on 'do X for',
  'how should we Y', 'check Z', …". The trigger phrases are what Claude
  Code's auto-router uses to fire the skill — and what
  .github/copilot-instructions.md uses to route Copilot free-form requests.
version: "1.0"
updated: "YYYY-MM-DD"
---

# Skill Name

## Safety — Read First
- Explicit rules the agent must NOT break (no fabricating numbers, etc.)
- Mandatory for any skill that touches money, client data, or compliance
- Always ends regulated outputs with a reviewer reminder

## The Process
1. Step-by-step pipeline the skill follows
2. Keep it 4-6 steps

## Output Template
Fixed format the skill must produce, every time.
Format consistency is the entire value of a skill — never let it drift.

## Worked Examples
At least one INPUT → OUTPUT example. Two is better.

## Reference (Secondary)
Lookup tables, edge cases, "when to stop and ask" rules.
```

**Hard rules:**
- `description` ≥ 150 characters — or Claude Code won't auto-trigger
- Keep the file **under ~500 lines** (split if it grows beyond)
- Worked examples beat rules — at least one
- Safety block is mandatory if the skill touches financial data, client info, or compliance

### Step 2 — Register the skill in three places

The same skill name needs to appear in three registries so all three platforms pick it up. This is the **only** manual sync step.

**a) `scripts/install-skills.sh`** — add to the `SKILLS=()` array:

```bash
SKILLS=(
  "am-skills/portfolio-review"
  "am-skills/investment-memo"
  ...
  "am-skills/your-new-skill"          # ← add here
  ...
)
```

**b) `AGENTS.md`** — add a row under the appropriate Layer section:

```markdown
| [your-new-skill](am-skills/your-new-skill/SKILL.md) | One-line description of when to use it |
```

**c) `docs/index.html`** — add an entry to the `SKILLS` array in the inline `<script>` block (search for `const SKILLS = [`):

```javascript
{id:"your-new-skill",layer:"am",icon:"📊",title:"Your New Skill",
 desc:"Short marketing description — what the skill does and what makes it useful.",
 triggers:["trigger phrase 1","trigger phrase 2","trigger phrase 3"],
 ex:{in:"One-line example input the user might type.",
     out:"One-line summary of what the skill produces."},
 file:"../am-skills/your-new-skill/SKILL.md"},
```

Also bump the skill count in `docs/index.html` (search for the current number, e.g. `"11"`) in:
- The `<title>` and `<meta name="description">`
- The hero `<p class="hero-sub">`
- The KPI strip `data-count` for Skills
- The "Browse all X skills" section title

### Step 3 — Regenerate adapters

```bash
./scripts/install-skills.sh --all
```

This:
- Regenerates `.github/prompts/<your-new-skill>.prompt.md` for Copilot
- Copies `SKILL.md` into `~/.claude/skills/<your-new-skill>.md` for Claude

Codex needs no regeneration — it reads `AGENTS.md` directly on the next session.

### Step 4 — Verify

```bash
# 1. Confirm the Copilot prompt file was created
ls .github/prompts/<your-new-skill>.prompt.md

# 2. Confirm the Claude install picked it up
ls ~/.claude/skills/<your-new-skill>.md

# 3. Open docs/index.html in a browser, find your skill card, click it,
#    and confirm the modal renders the source correctly
open docs/index.html
```

### Step 5 — Test on each platform

| Platform | Quick smoke test |
|----------|------------------|
| **Claude Code** | In a new Claude Code session, type `/your-new-skill` — confirm it loads. Then try the free-form trigger phrase — confirm auto-routing fires. |
| **GitHub Copilot** | Open this repo in VS Code, open Copilot Chat, type `/your-new-skill` — confirm it loads. Try free-form trigger — `.github/copilot-instructions.md` should route. |
| **OpenAI Codex** | Start a Codex session in this repo. Ask "use the your-new-skill skill on …" — confirm Codex opens the `SKILL.md`. |

### Skill checklist (TL;DR)

- [ ] `<layer>/<skill-name>/SKILL.md` created with canonical structure
- [ ] `description` field is ≥ 150 chars and contains realistic trigger phrases
- [ ] Safety block included (if regulated / touches data)
- [ ] At least one worked example
- [ ] File is < 500 lines
- [ ] Added to `scripts/install-skills.sh` `SKILLS=()` array
- [ ] Added to `AGENTS.md` Layers and Skills section
- [ ] Added to `docs/index.html` `SKILLS` array + counts bumped
- [ ] `./scripts/install-skills.sh --all` run successfully
- [ ] Smoke-tested on at least one platform

### Common pitfalls

| Mistake | Effect |
|---------|--------|
| `description` < 150 chars | Claude Code's auto-router won't fire the skill |
| Forgetting `AGENTS.md` update | Codex won't see the new skill |
| Forgetting `install-skills.sh` update | Copilot prompt file never generated; Claude install skips it |
| Inconsistent slug between filename and `name:` frontmatter | Slash-command routing breaks |
| Output template includes placeholders that look like real data | Models may hallucinate numbers to match the format — always use clearly fake placeholders like `${X}` or `{value}` |
| Skipping the Safety block on a regulated skill | Outputs may give advice or omit reviewer reminders |

---

## Team Setup

1. Copy `templates/TEAM.md` and `templates/SPRINT.md` to your project root.
2. Fill in `SPRINT.md` with your current initiative tasks and owners.
3. Each team member runs `/daily-checkin` once a day — takes 30 seconds.
4. Run `/team-digest` any time for a team summary.

---

## Repo Structure

```
am-playbook/
├── README.md
├── AGENTS.md                      ← Universal agent instructions (Codex, Cursor, etc.)
├── am-skills/                     ← AM domain (portfolio, memo, reporting, risk, CLO)
├── dev-basics/                    ← Pseudo-developer skills
├── pm-skills/                     ← Project management
├── templates/                     ← TEAM.md, SPRINT.md
├── scripts/install-skills.sh      ← Cross-platform installer / generator
├── .github/
│   ├── copilot-instructions.md    ← Copilot repo behaviour
│   └── prompts/                   ← Generated Copilot slash-command prompt files
└── docs/index.html                ← Browsable skills site
```

---

## Skill Writing Patterns

- **Description ≥ 150 chars** with realistic trigger phrases — or the skill won't auto-trigger in Claude.
- **Always include an output template** — format must not drift run-to-run.
- **One worked example beats five rules.** Two is better.
- **Keep each skill under 500 lines.**
- **Safety block is mandatory** for any skill that touches client data, money, or compliance.
- **End regulated outputs with a reviewer reminder** (firm compliance / IC). Never remove these.
