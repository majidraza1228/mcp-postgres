---
name: ticket-writer
description: >
  Use this skill when writing a well-formed task, action item, or issue for an
  AM team's tracker (Jira, Linear, Notion, Asana, or any task system). Triggers
  on 'write a ticket for', 'create a task for', 'turn this into a task', 'write
  up this action item', 'help me write a task', 'formalize this into a ticket',
  'write an issue for', or when the user pastes rough notes and asks to make them
  a proper task. Covers ops tasks, data requests, compliance items, project
  deliverables, and bugs in internal tools. Do NOT use for planning a full
  project — use /skills/sprint-planning instead.
version: "1.0"
updated: "2026-06-13"
---

# Ticket Writer Skill (AM Edition)

## Safety — Read First

- NEVER include client names, account numbers, or sensitive fund data in a ticket that will be visible to unauthorised users
- NEVER invent acceptance criteria that weren't implied by the user — flag gaps and ask
- If the task involves regulatory or compliance implications, add a COMPLIANCE label and flag for review

## Output Template

```
**Title:** {verb + subject — max 72 chars, action-oriented}

**Type:** {Task / Bug / Analysis / Data Request / Compliance / Ops / Investigation}
**Priority:** {Critical / High / Medium / Low}
**Estimate:** {XS / S / M / L / XL}
**Labels:** {comma-separated}
**Due:** {date or sprint, if known}

---

**Context / Problem**
{2-4 sentences. What needs to be done and why it matters. For bugs in tools: what the user sees vs what should happen.}

**Acceptance Criteria**
- [ ] {criterion 1 — specific and verifiable, starts with a verb}
- [ ] {criterion 2}
- [ ] {criterion 3}

**Notes / Context for the assignee**
{Anything that helps them do the task: relevant files, systems, contacts, precedents. Skip if not needed.}

**Out of scope**
- {explicitly not included in this task}

**Links**
- {Related task, document, or system URL if applicable}
```

## Worked Examples

### Example 1 — Data task

INPUT: "We need to fix the fact that our performance report pulls stale NAV data. The report is using last month's NAV for this month's returns."

OUTPUT:
```
**Title:** Fix stale NAV data in monthly performance report

**Type:** Bug
**Priority:** High
**Estimate:** M
**Labels:** performance, data, reporting
**Due:** Before next month-end run

---

**Context / Problem**
The monthly performance report is currently calculating returns using the prior month's NAV instead of the current month's NAV. This results in incorrect return figures being shown in client reports. The issue was first identified in the June 2026 report run.

**Acceptance Criteria**
- [ ] Identify where in the report process the NAV data is sourced (script, database query, or manual input)
- [ ] Fix the data pull so the report uses the as-of-date NAV for each respective period
- [ ] Run a parallel comparison of corrected vs incorrect output and confirm the differences are explained
- [ ] June 2026 corrected report produced and signed off before distribution

**Notes / Context for the assignee**
- The report generation script is in `reports/monthly_performance.py`
- NAV data is stored in the `nav` table — check the `as_of_date` filter in the query
- Prior correct version was the April 2026 run — compare against that as a baseline

**Out of scope**
- Historical report corrections (unless compliance requires them)
- Redesigning the reporting workflow

**Links**
- Monthly performance report template: {link}
```

### Example 2 — Compliance action item

INPUT: "We got an audit finding that our investment guideline breach monitoring is manual and needs to be automated by end of Q3."

OUTPUT:
```
**Title:** Automate investment guideline breach monitoring

**Type:** Compliance
**Priority:** High
**Estimate:** L
**Labels:** compliance, automation, mandate-monitoring
**Due:** 30 Sep 2026 (Q3 end — audit commitment)

---

**Context / Problem**
An internal audit finding identified that our investment guideline breach monitoring is currently a manual process, creating operational risk and audit exposure. We are committed to delivering an automated solution by end of Q3 2026. Manual checking is currently performed weekly by the risk team and relies on Excel, which has resulted in two delayed breach identifications in the past 12 months.

**Acceptance Criteria**
- [ ] Document all current guideline checks performed manually and their frequency
- [ ] Design automated monitoring logic covering all current manual checks
- [ ] Build or procure automated monitoring solution (internal script or risk system enhancement)
- [ ] Run parallel for 4 weeks — automated checks match manual checks with no unexplained differences
- [ ] Breach alerts delivered to risk team in real time (or T+1 at latest)
- [ ] Compliance sign-off on solution before going live
- [ ] Audit closure memo drafted and submitted

**Notes / Context for the assignee**
- Current manual process is documented in `compliance/guideline-check-runbook.xlsx`
- Risk team contact for requirements: {name}
- Audit finding reference: {ID}

**Out of scope**
- Automated breach remediation (monitoring only — remediation is still a human decision)
- Expanding the scope of guidelines checked beyond current list

**Links**
- Audit finding: {link}
- Current runbook: {link}
```

### Example 3 — Analysis request

INPUT: "I need someone to analyse our sector concentration vs peers — want to know if we're running outlier bets."

OUTPUT:
```
**Title:** Analyse sector concentration vs peer group

**Type:** Analysis
**Priority:** Medium
**Estimate:** M
**Labels:** risk, portfolio-analysis, peer-comparison
**Due:** {to be set}

---

**Context / Problem**
We want to understand whether our sector weights represent meaningful differentiated bets versus peers, or whether we are inadvertently running passive-like exposure in some areas. This analysis will inform IC positioning discussion at the next quarterly review.

**Acceptance Criteria**
- [ ] Define peer group (at least 5 comparable funds — confirm with PM)
- [ ] Source peer sector weights (Morningstar, eVestment, or Bloomberg peer data)
- [ ] Calculate our active sector tilts vs average peer and vs peer range (min/max)
- [ ] Identify sectors where we are statistical outliers vs peer group
- [ ] Summarise findings in a 1-page table or chart suitable for IC deck

**Notes / Context for the assignee**
- Focus on major sectors (GICS Level 1) rather than sub-sectors for this first pass
- Our sector weights are available in the risk system — check `positions` table with sector join
- Peer group suggestion: {names or universe}

**Out of scope**
- Factor-based peer comparison (separate analysis)
- Attribution of returns vs peers

**Links**
- IC deck template: {link}
```

## Ticket-Writing Rules (Secondary Reference)

**Title formula:**
- Task: `{Verb} {what} {context}`
- Bug: `Fix {what breaks} {where/when}`
- Analysis: `Analyse {topic} for {purpose}`
- Compliance: `{Implement/Automate/Review} {requirement} by {deadline}`

**Acceptance criteria formula:** Given → when → then. Must be individually testable.
Aim for 3-5 criteria — more means the task is too large.

**When to split a task:**
- Estimate is XL
- More than 6 acceptance criteria
- Requires sign-off from more than 2 separate teams
- Could be done by different people independently
