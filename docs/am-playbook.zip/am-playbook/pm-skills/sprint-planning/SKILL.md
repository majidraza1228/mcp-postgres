---
name: sprint-planning
description: >
  Use this skill when planning a project, initiative, or work cycle for an AM
  team. Triggers on 'plan this project', 'break this initiative into tasks',
  'what should we work on this sprint', 'help me prioritise the backlog',
  'plan this quarter's work', 'scope this deliverable', 'create a task list
  for', 'how long will this take', 'what are the dependencies', or 'plan the
  onboarding project'. Works for investment operations, data projects, reporting
  buildouts, compliance initiatives, and team workflows. Do NOT use for writing
  individual tasks in detail — use /skills/ticket-writer instead. Do NOT use
  for portfolio planning — use /skills/portfolio-review instead.
version: "1.0"
updated: "2026-06-13"
---

# Sprint Planning Skill (AM Edition)

## Safety — Read First

- NEVER invent estimates without flagging them as rough guesses
- NEVER create tasks without a definition of done — an undone task is just a to-do list
- If a hard deadline exists (regulatory, client, board), surface any scope risk before the task list

## Output Template

```
## Plan: {Initiative / Project Name}

**Duration:** {N weeks / months}
**Goal:** {one sentence — what does a successful outcome look like?}
**Owner:** {team or person responsible}

### Tasks

| # | Task | Size | Priority | Depends on | Owner | Status |
|---|------|------|----------|------------|-------|--------|
| 1 | {task} | {XS/S/M/L/XL} | {P0/P1/P2} | {# or —} | {name} | NOT STARTED |

### Scope Risks
- {risk — what could blow up, who needs to act}

### Out of scope (parking lot)
- {item}: {reason for deferral}

### Definition of done
- {criterion 1 — specific and verifiable}
- {criterion 2}
```

## Worked Examples

### Example 1 — Client reporting buildout

INPUT: "We need to build a monthly client reporting process. Currently it's done manually in Excel, takes 3 days, and is full of errors. We want to automate it. 6-week project."

OUTPUT:
```
## Plan: Monthly Client Reporting Automation

**Duration:** 6 weeks
**Goal:** Automated monthly client reports generated in <4 hours with zero manual data entry.
**Owner:** Investment Operations

### Tasks

| # | Task | Size | Priority | Depends on | Owner | Status |
|---|------|------|----------|------------|-------|--------|
| 1 | Map current manual process end-to-end — document all data sources, steps, and error points | S | P0 | — | Ops Lead | NOT STARTED |
| 2 | Identify data sources to automate (Bloomberg, Aladdin, internal DB) | S | P0 | 1 | Data team | NOT STARTED |
| 3 | Build data extraction scripts for each source | L | P0 | 2 | Data team | NOT STARTED |
| 4 | Design report template in agreed format (PDF / Excel) | M | P0 | 1 | Ops Lead | NOT STARTED |
| 5 | Build report generation script — merge data into template | L | P0 | 3, 4 | Data team | NOT STARTED |
| 6 | Parallel run: auto report vs manual — reconcile differences | M | P0 | 5 | Ops Lead | NOT STARTED |
| 7 | Sign-off from compliance on report format and disclosures | S | P0 | 4 | Compliance | NOT STARTED |
| 8 | Train ops team on new process + document runbook | S | P1 | 6, 7 | Ops Lead | NOT STARTED |
| 9 | First live run with new process | S | P0 | 8 | Ops Lead | NOT STARTED |

### Scope Risks
- Data extraction (task 3) is most uncertain — Bloomberg/Aladdin API access and data quality issues could delay this by 1-2 weeks
- Compliance sign-off (task 7) is on the critical path — engage early, don't wait until the end

### Out of scope (parking lot)
- Client portal / self-service reporting: future phase
- Customised reporting per client: standardise first, customise later
- Historical data backfill: not needed for first live run

### Definition of done
- Automated report generated in <4 hours for last month's data
- Report passes parallel run vs manual (no unexplained differences >1bp)
- Compliance sign-off obtained
- Runbook documented and ops team trained
```

### Example 2 — Due diligence project

INPUT: "We're doing due diligence on a new external manager. 4 week timeline. We need to cover investment process, risk, operations, legal, and team."

OUTPUT:
```
## Plan: External Manager Due Diligence — {Manager Name}

**Duration:** 4 weeks
**Goal:** IC-ready DD report with go / no-go recommendation.
**Owner:** Investment team + Ops

### Tasks

| # | Task | Size | Priority | Depends on | Owner | Status |
|---|------|------|----------|------------|-------|--------|
| 1 | Request DD questionnaire + track record data from manager | XS | P0 | — | PM | NOT STARTED |
| 2 | Review investment process — strategy, philosophy, edge | M | P0 | 1 | Analyst | NOT STARTED |
| 3 | Performance attribution and risk analysis | M | P0 | 1 | Risk | NOT STARTED |
| 4 | Reference calls — current and former clients | M | P1 | — | PM | NOT STARTED |
| 5 | Operational due diligence — custodian, admin, controls | M | P0 | 1 | Ops | NOT STARTED |
| 6 | Legal and compliance review — fund documents, terms | M | P0 | 1 | Legal | NOT STARTED |
| 7 | Team assessment — key man risk, succession, culture | S | P0 | 2, 4 | PM | NOT STARTED |
| 8 | On-site / video meeting with PMs and COO | S | P0 | 2, 5 | PM | NOT STARTED |
| 9 | Draft IC DD report | L | P0 | 2, 3, 5, 6, 7, 8 | Analyst | NOT STARTED |
| 10 | IC presentation and decision | S | P0 | 9 | PM | NOT STARTED |

### Scope Risks
- Manager responsiveness (task 1) sets the pace for everything — follow up on day 1
- Legal review (task 6) may surface issues that require external counsel — flag early

### Out of scope
- Mandate negotiation: only after IC go decision
- System onboarding: only after contract signed

### Definition of done
- IC report complete and reviewed by investment team
- Go / no-go decision recorded in IC minutes
```

## Sizing Guide

| Size | Effort | AM Examples |
|------|--------|------------|
| XS | < 2h | Send a request email, pull a data file, fill a form |
| S | 2–4h | Write a section of a report, run a standard analysis, one stakeholder call |
| M | 4–8h | Build an analysis model, run DD workstream, design a template |
| L | 1–2 days | Build an automation, write an IC report, complete a legal review |
| XL | 2–5 days | Split into multiple tasks |

## Priority Guide

- **P0:** The project fails or is blocked without it
- **P1:** Important but not a blocker — do if time allows
- **P2:** Nice to have — park if timeline is tight
