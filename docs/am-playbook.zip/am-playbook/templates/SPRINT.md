# {Initiative / Sprint Name}

**Goal:** {one sentence — what does success look like?}
**Start:** {YYYY-MM-DD}
**End:** {YYYY-MM-DD}
**Team:** @{member1}, @{member2}, @{member3}
**Type:** {Project / Quarter / Sprint / IC Cycle}

---

## Tasks

Update status by editing the Status column.
Status options: `NOT STARTED` · `IN PROGRESS` · `BLOCKED` · `DONE`

| # | Task | Owner | Size | Priority | Depends on | Due | Status |
|---|------|-------|------|----------|------------|-----|--------|
| 1 | {task description} | @{owner} | S | P0 | — | {date} | NOT STARTED |
| 2 | {task description} | @{owner} | M | P0 | 1 | {date} | NOT STARTED |
| 3 | {task description} | @{owner} | M | P1 | — | {date} | NOT STARTED |

---

## Blockers

Active blockers — resolved or escalated in the daily digest.

| Blocker | Who's blocked | Who needs to act | Raised | Resolved |
|---------|--------------|-----------------|--------|----------|
| {description} | @{user} | @{owner / team} | {date} | — |

---

## Parking Lot

Items descoped from this sprint. Revisit in next planning cycle.

- {item}: {reason for deferral}

---

## Definition of Done

- [ ] All P0 tasks complete and signed off
- [ ] Relevant stakeholders (compliance, clients, IC) notified
- [ ] Documentation updated
- [ ] No open P0 blockers
